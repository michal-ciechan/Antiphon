import pathlib,subprocess,json,time,re,hashlib
root=pathlib.Path.cwd(); folder=root/'.antiphon/card0395-continuation'; source=root/'tests/Antiphon.Tests/Agents/Fixtures/grok-rules-live-inline-1.0.13.json'
original=source.read_bytes(); ledger=[]
command=['dotnet','run','--project','tests/Antiphon.Tests','--property:OutputPath=bin-card0395/','--','--treenode-filter','/*/*/GrokRulesLiveEvidenceTests/*']
def run(name):
 start=time.monotonic(); log=folder/(name+'.log')
 with log.open('w',encoding='utf-8') as stream: result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
 output=log.read_text(encoding='utf-8'); counts={k:int(v) for k,v in re.findall(r'^\s*(total|failed|succeeded|skipped):\s*(\d+)',output,re.M)}
 assertion=re.search(r'ShouldAssertException:[\s\S]*?(?=\n\s+at |\Z)',output)
 return {'name':name,'exit':result.returncode,'seconds':round(time.monotonic()-start,3),'counts':counts,'assertion':assertion.group(0) if assertion else None}
try:
 for mutation in ['expected-row','duplicate-native-id']:
  data=json.loads(original)
  if mutation=='expected-row': data['checkpoints'][1]['Expected'][0]='MUTATED-CAPTURED-EXPECTED'
  else: data['manifest']['compactIds'][1]=data['manifest']['compactIds'][0]
  source.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
  red=run('PC-31-'+mutation+'-red'); ledger.append(red)
  source.write_bytes(original)
  green=run('PC-31-'+mutation+'-green'); ledger.append(green)
  (folder/'pc31-ledger.json').write_text(json.dumps(ledger,indent=2),encoding='utf-8')
  print(json.dumps([red,green]),flush=True)
  assert red['exit']!=0 and red['counts']=={'total':1,'failed':1,'succeeded':0,'skipped':0} and red['assertion']
  assert green['exit']==0 and green['counts']=={'total':1,'failed':0,'succeeded':1,'skipped':0}
finally:
 source.write_bytes(original)
 (folder/'pc31-ledger.json').write_text(json.dumps(ledger,indent=2),encoding='utf-8')
 print('restored',hashlib.sha256(source.read_bytes()).hexdigest(),flush=True)
