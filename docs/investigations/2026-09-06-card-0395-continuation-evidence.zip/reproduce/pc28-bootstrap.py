import pathlib,subprocess,json,time,re,os
root=pathlib.Path.cwd();folder=root/'.antiphon/card0395-continuation';source=root/'tests/Antiphon.Tests/Application/GrokRulesDispatchAcceptanceTests.cs';original=source.read_bytes();ledger=[]
env=os.environ.copy();env['ANTIPHON_HEADED_TESTS']='1';env['ANTIPHON_REAL_CLI_STUB_TESTS']='1'
command=['dotnet','run','--project','tests/Antiphon.Tests','--property:OutputPath=bin-card0395/','--','--treenode-filter','/*/*/GrokRulesDispatchAcceptanceTests/Real_cli_delegate_wire_reads_full_rules_before_brief_and_settles']
def run(name):
 start=time.monotonic();log=folder/(name+'.log')
 with log.open('w',encoding='utf-8') as stream:result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,env=env)
 output=log.read_text(encoding='utf-8');counts={k:int(v) for k,v in re.findall(r'^\s*(total|failed|succeeded|skipped):\s*(\d+)',output,re.M)}
 assertion=re.search(r'ShouldAssertException:[\s\S]*?(?=\n\s+at |\Z)',output)
 return {'name':name,'exit':result.returncode,'seconds':round(time.monotonic()-start,3),'counts':counts,'assertion':assertion.group(0) if assertion else None}
try:
 s=original.decode('utf-8');needle='                if (!outputs.Any(i => i.ToString().Contains("card0395-rules-read")))';assert s.count(needle)==1
 s=s.replace(needle,'''                // PC-28: move only this run's file after runner receipt/argv commit and before native read.
                // The actual native bootstrap and queued refresh now both name a missing disposable file.
                var ownedFile = Path.GetFullPath(rulesPath);
                var ownedRoot = Directory.GetParent(ownedFile)!.Parent!.Parent!.Parent!.FullName;
                if (!ownedRoot.StartsWith(Path.GetFullPath(Path.GetTempPath()), StringComparison.OrdinalIgnoreCase)
                    || !Path.GetFileName(ownedRoot).StartsWith("antiphon-e2e-runner-", StringComparison.Ordinal)
                    || ownedFile != Path.Combine(ownedRoot, "instructions", "grok", sessionId.ToString("N"), "rules.md"))
                    throw new InvalidOperationException("PC-28 disposable rules ownership mismatch");
                if (File.Exists(rulesPath)) File.Move(rulesPath, rulesPath + ".pc28-retained");
'''+needle)
 source.write_text(s,encoding='utf-8');red=run('PC-28-bootstrap-missing-red');ledger.append(red)
 source.write_bytes(original);green=run('PC-28-bootstrap-missing-green');ledger.append(green)
 print(json.dumps(ledger),flush=True)
 assert red['exit']!=0 and red['counts']=={'total':1,'failed':1,'succeeded':0,'skipped':0} and red['assertion']
 assert green['exit']==0 and green['counts']=={'total':1,'failed':0,'succeeded':1,'skipped':0}
finally:
 source.write_bytes(original);(folder/'pc28-bootstrap-ledger.json').write_text(json.dumps(ledger,indent=2),encoding='utf-8')
