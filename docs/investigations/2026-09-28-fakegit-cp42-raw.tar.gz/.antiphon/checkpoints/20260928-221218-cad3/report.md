--- checkpoint report ---
run: 20260928-221218-cad3   manifest: /work/worktrees/task-2aa8cd10/.antiphon/checkpoints/20260928-221218-cad3/manifest.resolved.yaml
commit: e0d450f947194c3f3129557a4ab9effd981ff032  branch: feat/card-task-2aa8cd10  worktree: /work/worktrees/task-2aa8cd10  host: Debian GNU/Linux 12 (bookworm) cores=24
CHECKPOINT CP-42 commit=e0d450f947194c3f3129557a4ab9effd981ff032 build=ok filter=/*/Antiphon.Tests.Application/AgentTaskLandBoundaryTests/(C448_V10_EachAcknowledgedBoundaryRechecksSource*)|(C448_V11_TargetMutationAfterFastForwardCannotBeAcknowledged*) executed=19 passed=19 failed=0 skipped=0 trx=/work/worktrees/task-2aa8cd10/.antiphon/checkpoints/20260928-221218-cad3/rows/CP-42/run.trx slot=granted waited=0s
unlisted: none (the tool ran no other build or test command)
wall: 4m37s  sequential-equivalent: 1m16s  builds: 13  rows: 1 green 0 red 0 skipped
outputs: deleted bin-fakegit-s1/, bin-fakegit-s2-trace/, bin-fakegit-s2/, bin-fakegit-s3/, bin-fakegit-s4/, bin-fakegit-s5/, bin-fakegit-s6/, bin-fakegit-s7/, bin-fakegit-s8/, bin-fakegit-s9/, bin-fakegit-s10/, bin-fakegit-s11/, bin-fakegit-native-windows/
evidence: /work/worktrees/task-2aa8cd10/.antiphon/checkpoints/20260928-221218-cad3/report.md
verdict: GREEN exit=0
