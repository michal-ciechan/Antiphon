--- checkpoint report ---
run: 20261003-184602-9733   manifest: /work/worktrees/task-818582a5/.antiphon/c959-second/20261003-184602-9733/manifest.resolved.yaml
commit: 95e942a0646ca858db2f73c35f85bab7a44fc658  branch: feat/card-task-818582a5  worktree: /work/worktrees/task-818582a5  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 95e942a0646ca858db2f73c35f85bab7a44fc658 state=clean buildSource=verified
CHECKPOINT CP-4 commit=95e942a0646ca858db2f73c35f85bab7a44fc658 build=ok filter=/*/*/CodexCliAdmissionTests*/C959_* executed=9 passed=9 failed=0 skipped=0 trx=/work/worktrees/task-818582a5/.antiphon/c959-second/20261003-184602-9733/rows/CP-4/run.trx slot=granted waited=0s dirty=0 source=95e942a0646ca858db2f73c35f85bab7a44fc658 sourceState=clean buildSource=verified
PHASES CP-4 slotWait=0s build=123.7942836s startup=48.3066696s testsWall=50.9568828s teardown=1.4921292s hostWall=100.7556924s
unlisted: none (the tool ran no other build or test command)
wall: 3m45s  sequential-equivalent: 1m41s  builds: 8  max-concurrent-builds: 1  rows: 1 green 0 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/, bin-c959-unit/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-184602-9733
evidence: /work/worktrees/task-818582a5/.antiphon/c959-second/20261003-184602-9733/report.md
verdict: GREEN exit=0
