--- checkpoint report ---
run: 20261003-184351-7c60   manifest: /work/worktrees/task-818582a5/.antiphon/c959-second/20261003-184351-7c60/manifest.resolved.yaml
commit: 45ed0e62ba00d4f62759c3257b40c30711a471de  branch: feat/card-task-818582a5  worktree: /work/worktrees/task-818582a5  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 45ed0e62ba00d4f62759c3257b40c30711a471de state=clean buildSource=unknown
CHECKPOINT CP-4 commit=45ed0e62ba00d4f62759c3257b40c30711a471de build=failed filter=/*/*/CodexCliAdmissionTests*/C959_* executed=n/a passed=n/a failed=n/a skipped=n/a trx=n/a slot=skipped waited=0s dirty=0 source=45ed0e62ba00d4f62759c3257b40c30711a471de sourceState=clean buildSource=unknown
unlisted: none (the tool ran no other build or test command)
wall: 1m13s  sequential-equivalent: 0m00s  builds: 8  max-concurrent-builds: 1  rows: 0 green 1 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/, bin-c959-unit/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-184351-7c60
evidence: /work/worktrees/task-818582a5/.antiphon/c959-second/20261003-184351-7c60/report.md
verdict: RED exit=2
