--- checkpoint report ---
run: 20261003-190721-c37b   manifest: /work/worktrees/task-818582a5/.antiphon/c959-second/20261003-190721-c37b/manifest.resolved.yaml
commit: 3ccc171bdaedffaf48838dfa744c6129d82c06ef  branch: feat/card-task-818582a5  worktree: /work/worktrees/task-818582a5  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 3ccc171bdaedffaf48838dfa744c6129d82c06ef state=clean buildSource=verified
CHECKPOINT CP-4 commit=3ccc171bdaedffaf48838dfa744c6129d82c06ef build=ok filter=/*/*/CodexCliAdmissionTests*/C959_* executed=9 passed=9 failed=0 skipped=0 trx=/work/worktrees/task-818582a5/.antiphon/c959-second/20261003-190721-c37b/rows/CP-4/run.trx slot=granted waited=0s dirty=0 source=3ccc171bdaedffaf48838dfa744c6129d82c06ef sourceState=clean buildSource=verified
PHASES CP-4 slotWait=0s build=86.7416546s startup=39.8865747s testsWall=68.44253s teardown=1.3150952s hostWall=109.644202s
SLOW CLASS Antiphon.Tests.Application.CodexCliAdmissionTests 68s tests=9 (CP-4)
unlisted: none (the tool ran no other build or test command)
wall: 3m17s  sequential-equivalent: 1m50s  builds: 8  max-concurrent-builds: 1  rows: 1 green 0 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/, bin-c959-unit/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-190721-c37b
evidence: /work/worktrees/task-818582a5/.antiphon/c959-second/20261003-190721-c37b/report.md
verdict: GREEN exit=0
