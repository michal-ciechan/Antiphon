--- checkpoint report ---
run: 20261003-185639-7d72   manifest: /work/worktrees/task-818582a5/.antiphon/c959-second/20261003-185639-7d72/manifest.resolved.yaml
commit: a3192200d821559c0f5fe8947923732da5c81c34  branch: feat/card-task-818582a5  worktree: /work/worktrees/task-818582a5  host: Debian GNU/Linux 12 (bookworm) cores=24
source: a3192200d821559c0f5fe8947923732da5c81c34 state=clean buildSource=verified
CHECKPOINT CP-4 commit=a3192200d821559c0f5fe8947923732da5c81c34 build=ok filter=/*/*/CodexCliAdmissionTests*/C959_* executed=9 passed=8 failed=1 skipped=0 trx=/work/worktrees/task-818582a5/.antiphon/c959-second/20261003-185639-7d72/rows/CP-4/run.trx slot=granted waited=0s dirty=0 source=a3192200d821559c0f5fe8947923732da5c81c34 sourceState=clean buildSource=verified
PHASES CP-4 slotWait=0s build=97.6129375s startup=36.8986377s testsWall=61.4106826s teardown=2.1920645s hostWall=100.5013917s
FAILED Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner (CP-4) ShouldAssertException: await h.Runtime.CatchUpTranscriptAsync(task.AgentSessionId.Value, CancellationToken.None)     should be True     but was False -> rows/CP-4/failures.md
SLOW CLASS Antiphon.Tests.Application.CodexCliAdmissionTests 61s tests=9 (CP-4)
unlisted: none (the tool ran no other build or test command)
wall: 3m20s  sequential-equivalent: 1m41s  builds: 8  max-concurrent-builds: 1  rows: 0 green 1 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/, bin-c959-unit/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-185639-7d72
evidence: /work/worktrees/task-818582a5/.antiphon/c959-second/20261003-185639-7d72/report.md
verdict: RED exit=1
