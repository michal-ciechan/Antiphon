## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner
outcome: Failed
durationSeconds: 21.0701784
baseline: n/a
message:
ShouldAssertException: await h.Runtime.CatchUpTranscriptAsync(task.AgentSessionId.Value, CancellationToken.None)
    should be
True
    but was
False
stack:
   at Antiphon.Tests.Application.CodexCliRemoteDeliveryFixture.RunAsync(String body, String version, Boolean busy) in /work/worktrees/task-818582a5/tests/Antiphon.Tests/Application/CodexCliRemoteDeliveryFixture.cs:line 155
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliRemoteDeliveryFixture.RunAsync(String body, String version, Boolean busy) in /work/worktrees/task-818582a5/tests/Antiphon.Tests/Application/CodexCliRemoteDeliveryFixture.cs:line 165
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliRemoteDeliveryFixture.RunAsync(String body, String version, Boolean busy) in /work/worktrees/task-818582a5/tests/Antiphon.Tests/Application/CodexCliRemoteDeliveryFixture.cs:line 165
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliRemoteDeliveryFixture.RunAsync(String body, String version, Boolean busy) in /work/worktrees/task-818582a5/tests/Antiphon.Tests/Application/CodexCliRemoteDeliveryFixture.cs:line 165
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliRemoteDeliveryFixture.RunAsync(String body, String version, Boolean busy) in /work/worktrees/task-818582a5/tests/Antiphon.Tests/Application/CodexCliRemoteDeliveryFixture.cs:line 165
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliRemoteDeliveryFixture.RunAsync(String body, String version, Boolean busy) in /work/worktrees/task-818582a5/tests/Antiphon.Tests/Application/CodexCliRemoteDeliveryFixture.cs:line 165
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliRemoteDeliveryFixture.RunAsync(String body, String version, Boolean busy) in /work/worktrees/task-818582a5/tests/Antiphon.Tests/Application/CodexCliRemoteDeliveryFixture.cs:line 167
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner() in /work/worktrees/task-818582a5/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 398
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Compatible_launch_keeps_model_and_runner" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Compatible_launch_keeps_model_and_runner"

