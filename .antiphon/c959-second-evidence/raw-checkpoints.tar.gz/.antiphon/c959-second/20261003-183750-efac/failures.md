## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Retry_and_cancellation_recheck
outcome: Failed
durationSeconds: 1.4735871
baseline: n/a
message:
DbUpdateException: An error occurred while saving the entity changes. See the inner exception for details.
stack:
   at Npgsql.EntityFrameworkCore.PostgreSQL.Update.Internal.NpgsqlModificationCommandBatch.Consume(RelationalDataReader reader, Boolean async, CancellationToken cancellationToken)
   at Microsoft.EntityFrameworkCore.Update.ReaderModificationCommandBatch.ExecuteAsync(IRelationalConnection connection, CancellationToken cancellationToken)
   at Microsoft.EntityFrameworkCore.Update.ReaderModificationCommandBatch.ExecuteAsync(IRelationalConnection connection, CancellationToken cancellationToken)
   at Microsoft.EntityFrameworkCore.Update.Internal.BatchExecutor.ExecuteAsync(IEnumerable`1 commandBatches, IRelationalConnection connection, CancellationToken cancellationToken)
   at Microsoft.EntityFrameworkCore.Update.Internal.BatchExecutor.ExecuteAsync(IEnumerable`1 commandBatches, IRelationalConnection connection, CancellationToken cancellationToken)
   at Microsoft.EntityFrameworkCore.Update.Internal.BatchExecutor.ExecuteAsync(IEnumerable`1 commandBatches, IRelationalConnection connection, CancellationToken cancellationToken)
   at Microsoft.EntityFrameworkCore.Storage.RelationalDatabase.SaveChangesAsync(IList`1 entries, CancellationToken cancellationToken)
   at Microsoft.EntityFrameworkCore.ChangeTracking.Internal.StateManager.SaveChangesAsync(IList`1 entriesToSave, CancellationToken cancellationToken)
   at Microsoft.EntityFrameworkCore.ChangeTracking.Internal.StateManager.SaveChangesAsync(StateManager stateManager, Boolean acceptAllChangesOnSuccess, CancellationToken cancellationToken)
   at Npgsql.EntityFrameworkCore.PostgreSQL.Storage.Internal.NpgsqlExecutionStrategy.ExecuteAsync[TState,TResult](TState state, Func`4 operation, Func`4 verifySucceeded, CancellationToken cancellationToken)
   at Microsoft.EntityFrameworkCore.DbContext.SaveChangesAsync(Boolean acceptAllChangesOnSuccess, CancellationToken cancellationToken)
   at Microsoft.EntityFrameworkCore.DbContext.SaveChangesAsync(Boolean acceptAllChangesOnSuccess, CancellationToken cancellationToken)
   at Antiphon.Server.Application.Services.AgentTaskDispatcher.FailAsync(AgentTask task, String reason, CancellationToken ct, Nullable`1 failureCode, Nullable`1 deliveryFailureNotificationId) in /work/worktrees/task-818582a5/server/Application/Services/AgentTaskDispatcher.cs:line 6601
   at Antiphon.Server.Application.Services.AgentTaskDispatcher.FailAndNotifyAsync(AgentTask task, String reason, String sweep, CancellationToken ct, Nullable`1 failureCode, IReadOnlyList`1 orphaned, Func`2 commitBeforeNotify) in /work/worktrees/task-818582a5/server/Application/Services/AgentTaskDispatcher.cs:line 3550
   at Antiphon.Server.Application.Services.AgentTaskDispatcher.TickAsync(CancellationToken ct) in /work/worktrees/task-818582a5/server/Application/Services/AgentTaskDispatcher.cs:line 996
   at Antiphon.Tests.Application.CodexCliAdmissionTests.DispatchKit.TickAsync(CancellationToken ct) in /work/worktrees/task-818582a5/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 649
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Retry_and_cancellation_recheck() in /work/worktrees/task-818582a5/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 478
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Retry_and_cancellation_recheck() in /work/worktrees/task-818582a5/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 508
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Retry_and_cancellation_recheck() in /work/worktrees/task-818582a5/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 514
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:
[testcontainers.org 00:01:21.53] Delete Docker container e89e5a8a693a

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Retry_and_cancellation_recheck" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Retry_and_cancellation_recheck"

