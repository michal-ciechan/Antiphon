--- checkpoint report ---
run: 20261003-183750-efac   manifest: /work/worktrees/task-818582a5/.antiphon/c959-second/20261003-183750-efac/manifest.resolved.yaml
commit: 4822d5b41532d0c6ad7b336c9934af0dc8249443  branch: feat/card-task-818582a5  worktree: /work/worktrees/task-818582a5  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 4822d5b41532d0c6ad7b336c9934af0dc8249443 state=clean buildSource=verified
CHECKPOINT CP-4 commit=4822d5b41532d0c6ad7b336c9934af0dc8249443 build=ok filter=/*/*/CodexCliAdmissionTests*/C959_* executed=9 passed=8 failed=1 skipped=0 trx=/work/worktrees/task-818582a5/.antiphon/c959-second/20261003-183750-efac/rows/CP-4/run.trx slot=granted waited=0s dirty=0 source=4822d5b41532d0c6ad7b336c9934af0dc8249443 sourceState=clean buildSource=verified
PHASES CP-4 slotWait=0s build=128.4608838s startup=47.1388086s testsWall=39.1768627s teardown=1.5070371s hostWall=87.8227245s
FAILED Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Retry_and_cancellation_recheck (CP-4) DbUpdateException: An error occurred while saving the entity changes. See the inner exception for details. -> rows/CP-4/failures.md
unlisted: none (the tool ran no other build or test command)
wall: 3m38s  sequential-equivalent: 1m28s  builds: 8  max-concurrent-builds: 1  rows: 0 green 1 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/, bin-c959-unit/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-183750-efac
evidence: /work/worktrees/task-818582a5/.antiphon/c959-second/20261003-183750-efac/report.md
verdict: RED exit=1
