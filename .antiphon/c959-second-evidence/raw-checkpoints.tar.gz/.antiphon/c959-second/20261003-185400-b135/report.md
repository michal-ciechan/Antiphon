--- checkpoint report ---
run: 20261003-185400-b135   manifest: /work/worktrees/task-818582a5/.antiphon/c959-second/20261003-185400-b135/manifest.resolved.yaml
commit: 8667f35e77a82cf220a0b6792991db610e6d6b16  branch: feat/card-task-818582a5  worktree: /work/worktrees/task-818582a5  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 8667f35e77a82cf220a0b6792991db610e6d6b16 state=clean buildSource=unknown
CHECKPOINT CP-4 commit=8667f35e77a82cf220a0b6792991db610e6d6b16 build=failed filter=/*/*/CodexCliAdmissionTests*/C959_* executed=n/a passed=n/a failed=n/a skipped=n/a trx=n/a slot=skipped waited=0s dirty=0 source=8667f35e77a82cf220a0b6792991db610e6d6b16 sourceState=clean buildSource=unknown
unlisted: none (the tool ran no other build or test command)
wall: 1m26s  sequential-equivalent: 0m00s  builds: 8  max-concurrent-builds: 1  rows: 0 green 1 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/, bin-c959-unit/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-185400-b135
evidence: /work/worktrees/task-818582a5/.antiphon/c959-second/20261003-185400-b135/report.md
verdict: RED exit=2
