--- checkpoint report ---
run: 20261003-182512-689d   manifest: /work/worktrees/task-818582a5/.antiphon/c959-second/20261003-182512-689d/manifest.resolved.yaml
commit: c8b75d44ed590f29d94dfae801d68a6e20a14790  branch: feat/card-task-818582a5  worktree: /work/worktrees/task-818582a5  host: Debian GNU/Linux 12 (bookworm) cores=24
source: c8b75d44ed590f29d94dfae801d68a6e20a14790 state=clean buildSource=verified
CHECKPOINT CP-4 commit=c8b75d44ed590f29d94dfae801d68a6e20a14790 build=ok filter=/*/*/CodexCliAdmissionTests*/C959_* executed=9 passed=9 failed=0 skipped=0 trx=/work/worktrees/task-818582a5/.antiphon/c959-second/20261003-182512-689d/rows/CP-4/run.trx slot=granted waited=0s dirty=0 source=c8b75d44ed590f29d94dfae801d68a6e20a14790 sourceState=clean buildSource=verified
PHASES CP-4 slotWait=0s build=209.0234737s startup=58.2077301s testsWall=51.8956242s teardown=1.067719s hostWall=111.1710772s
unlisted: none (the tool ran no other build or test command)
wall: 5m22s  sequential-equivalent: 1m51s  builds: 8  max-concurrent-builds: 1  rows: 1 green 0 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/, bin-c959-unit/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-182512-689d
evidence: /work/worktrees/task-818582a5/.antiphon/c959-second/20261003-182512-689d/report.md
verdict: GREEN exit=0
