--- checkpoint report ---
run: 20261003-190236-40fe   manifest: /work/worktrees/task-818582a5/.antiphon/c959-second/20261003-190236-40fe/manifest.resolved.yaml
commit: 95ad909ce517d025100baadc8f7c5c11bbe59fc6  branch: feat/card-task-818582a5  worktree: /work/worktrees/task-818582a5  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 95ad909ce517d025100baadc8f7c5c11bbe59fc6 state=clean buildSource=verified
CHECKPOINT CP-4 commit=95ad909ce517d025100baadc8f7c5c11bbe59fc6 build=ok filter=/*/*/CodexCliAdmissionTests*/C959_* executed=9 passed=8 failed=1 skipped=0 trx=/work/worktrees/task-818582a5/.antiphon/c959-second/20261003-190236-40fe/rows/CP-4/run.trx slot=granted waited=0s dirty=0 source=95ad909ce517d025100baadc8f7c5c11bbe59fc6 sourceState=clean buildSource=verified
PHASES CP-4 slotWait=0s build=97.7552559s startup=39.0805827s testsWall=73.5829361s teardown=0.9953054s hostWall=113.6588378s
FAILED Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner (CP-4) ShouldAssertException: receipts.Count     should be 1     but was 0  Additional Info:     C959-v21-remote-no-duplicate remote/0.159.1/busy=True -> rows/CP-4/failures.md
SLOW CLASS Antiphon.Tests.Application.CodexCliAdmissionTests 73s tests=9 (CP-4)
unlisted: none (the tool ran no other build or test command)
wall: 3m32s  sequential-equivalent: 1m54s  builds: 8  max-concurrent-builds: 1  rows: 0 green 1 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/, bin-c959-unit/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-190236-40fe
evidence: /work/worktrees/task-818582a5/.antiphon/c959-second/20261003-190236-40fe/report.md
verdict: RED exit=1
