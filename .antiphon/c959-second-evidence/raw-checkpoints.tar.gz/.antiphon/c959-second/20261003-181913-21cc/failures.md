## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner
outcome: Failed
durationSeconds: 4.0439942
baseline: n/a
message:
ShouldAssertException: adapter.SubmittedBodies
    should be empty but had
1
    item and was
["[antiphon-task:9e9de8fa] role=Docs tier=High workspace=Shared

C959 delivery α
second line
END-C959

When finished: git add the files you changed, commit with the real outcome in the message, and push, before your final report.

--- how to report back ---
Your final message is the entire report the caller receives. Nothing else from this
session is forwarded, and the caller cannot see your screen. If a file is your
deliverable, give its absolute path; an `[[attach:]]` marker here reaches only your
caller as text — it is never sent to any chat.

Lead with the outcome in one line: what you did or found, and whether it worked.
Then only what the caller needs in order to act — files changed, commands to rerun,
decisions that are theirs to make, what is blocking you.

No preamble, no restating the task, no narrating the steps you took, no sign-off.
If you ran tests or builds, give counts and the failures, not the passing output.
If you could not finish, say that in the first line and say exactly what stopped you.

If your report would run past 14,400 characters, write the full detail to
.antiphon/task-9e9de8fa.md and make your final message a summary that points
at that path.

End your final message with one line, on its own: `[antiphon-report:9e9de8fa done]` if the work
is complete, `[antiphon-report:9e9de8fa blocked]` if you need a decision or an answer to continue,
`[antiphon-report:9e9de8fa failed]` if you could not do it. Nothing after it. Without that line the
harness cannot tell your report from a status update and will ask you once.

[antiphon-task:9e9de8fa]"]

Additional Info:
    C959-pc-188 busy recipient ClaudeCode/busy=True/worktree=False/0.160.0
stack:
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner() in /work/worktrees/task-818582a5/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 354
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner() in /work/worktrees/task-818582a5/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 393
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner() in /work/worktrees/task-818582a5/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 393
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Compatible_launch_keeps_model_and_runner" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Compatible_launch_keeps_model_and_runner"

