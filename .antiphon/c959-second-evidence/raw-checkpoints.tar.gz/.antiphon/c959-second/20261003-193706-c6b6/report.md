--- checkpoint report ---
run: 20261003-193706-c6b6   manifest: /work/worktrees/task-818582a5/.antiphon/c959-second/20261003-193706-c6b6/manifest.resolved.yaml
commit: 6d2e6fb6fe51e0f32c3073b4936ff965775e6452  branch: feat/card-task-818582a5  worktree: /work/worktrees/task-818582a5  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 6d2e6fb6fe51e0f32c3073b4936ff965775e6452 state=clean buildSource=verified
CHECKPOINT CP-4 commit=6d2e6fb6fe51e0f32c3073b4936ff965775e6452 build=ok filter=/*/*/CodexCliAdmissionTests*/C959_* executed=9 passed=9 failed=0 skipped=0 trx=/work/worktrees/task-818582a5/.antiphon/c959-second/20261003-193706-c6b6/rows/CP-4/run.trx slot=granted waited=0s dirty=0 source=6d2e6fb6fe51e0f32c3073b4936ff965775e6452 sourceState=clean buildSource=verified
PHASES CP-4 slotWait=0s build=94.8977487s startup=38.2286744s testsWall=69.7671931s teardown=1.3914416s hostWall=109.3873169s
SLOW CLASS Antiphon.Tests.Application.CodexCliAdmissionTests 69s tests=9 (CP-4)
unlisted: none (the tool ran no other build or test command)
wall: 3m25s  sequential-equivalent: 1m50s  builds: 8  max-concurrent-builds: 1  rows: 1 green 0 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/, bin-c959-unit/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-193706-c6b6
evidence: /work/worktrees/task-818582a5/.antiphon/c959-second/20261003-193706-c6b6/report.md
verdict: GREEN exit=0
