--- checkpoint report ---
run: 20261003-181139-fda0   manifest: /work/worktrees/task-818582a5/.antiphon/c959-second/20261003-181139-fda0/manifest.resolved.yaml
commit: 8ee8c929aae94dde7fa0514f156d73301cb2cfe2  branch: feat/card-task-818582a5  worktree: /work/worktrees/task-818582a5  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 8ee8c929aae94dde7fa0514f156d73301cb2cfe2 state=clean buildSource=unknown
CHECKPOINT CP-4 commit=8ee8c929aae94dde7fa0514f156d73301cb2cfe2 build=failed filter=/*/*/CodexCliAdmissionTests*/C959_* executed=n/a passed=n/a failed=n/a skipped=n/a trx=n/a slot=skipped waited=0s dirty=0 source=8ee8c929aae94dde7fa0514f156d73301cb2cfe2 sourceState=clean buildSource=unknown
unlisted: none (the tool ran no other build or test command)
wall: 1m59s  sequential-equivalent: 0m00s  builds: 8  max-concurrent-builds: 1  rows: 0 green 1 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/, bin-c959-unit/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-181139-fda0
evidence: /work/worktrees/task-818582a5/.antiphon/c959-second/20261003-181139-fda0/report.md
verdict: RED exit=2
