--- checkpoint report ---
run: 20261003-191547-0744   manifest: /work/worktrees/task-818582a5/.antiphon/c959-second-final/20261003-191547-0744/manifest.resolved.yaml
commit: 3ccc171bdaedffaf48838dfa744c6129d82c06ef  branch: feat/card-task-818582a5  worktree: /work/worktrees/task-818582a5  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 3ccc171bdaedffaf48838dfa744c6129d82c06ef state=clean buildSource=verified
CHECKPOINT CP-1 commit=3ccc171bdaedffaf48838dfa744c6129d82c06ef build=ok filter=/*/*/CodexCliVersionProbeTests*/C959_* executed=5 passed=5 failed=0 skipped=0 trx=/work/worktrees/task-818582a5/.antiphon/c959-second-final/20261003-191547-0744/rows/CP-1/run.trx slot=granted waited=0s dirty=0 source=3ccc171bdaedffaf48838dfa744c6129d82c06ef sourceState=clean buildSource=verified
PHASES CP-1 slotWait=0s build=18.70507s startup=2.3448778s testsWall=65.7627698s teardown=0.6201396s hostWall=68.7278061s
SLOW CLASS Antiphon.SessionRunner.Tests.CodexCliVersionProbeTests 65s tests=5 (CP-1)
CHECKPOINT CP-3 commit=3ccc171bdaedffaf48838dfa744c6129d82c06ef build=ok filter=/*/*/RunnerCodexCliEvidenceTests*/C959_* executed=5 passed=5 failed=0 skipped=0 trx=/work/worktrees/task-818582a5/.antiphon/c959-second-final/20261003-191547-0744/rows/CP-3/run.trx slot=granted waited=0s dirty=0 source=3ccc171bdaedffaf48838dfa744c6129d82c06ef sourceState=clean buildSource=verified
PHASES CP-3 slotWait=0s build=101.2742981s startup=5.220839s testsWall=10.179645s teardown=0.410567s hostWall=15.8110513s
CHECKPOINT CP-5 commit=3ccc171bdaedffaf48838dfa744c6129d82c06ef build=ok filter=/*/*/(CodexPhoneHomeCreateTests*)|(PinnedCodexProfileDispatchLaunchTests*)|(ModelAvailabilityCreateTests*)|(ModelAvailabilityDispatcherTests*)/* executed=22 passed=22 failed=0 skipped=0 trx=/work/worktrees/task-818582a5/.antiphon/c959-second-final/20261003-191547-0744/rows/CP-5/run.trx slot=granted waited=0s dirty=0 source=3ccc171bdaedffaf48838dfa744c6129d82c06ef sourceState=clean buildSource=verified
PHASES CP-5 slotWait=0s build=90.9323303s startup=38.7110195s testsWall=22.1134318s teardown=1.4984817s hostWall=62.3229331s
CHECKPOINT CP-6 commit=3ccc171bdaedffaf48838dfa744c6129d82c06ef build=ok filter=/*/*/(RunnerCatalogueTests*)|(PhoneHomeDirectoryTests*)|(PhoneHomeRunnerRetirementIdentityTests*)/* executed=20 passed=20 failed=0 skipped=0 trx=/work/worktrees/task-818582a5/.antiphon/c959-second-final/20261003-191547-0744/rows/CP-6/run.trx slot=granted waited=0s dirty=0 source=3ccc171bdaedffaf48838dfa744c6129d82c06ef sourceState=clean buildSource=verified
PHASES CP-6 slotWait=0s build=94.1060155s startup=40.4200904s testsWall=6.6076452s teardown=1.1287082s hostWall=48.1564439s
CHECKPOINT CP-7 commit=3ccc171bdaedffaf48838dfa744c6129d82c06ef build=ok filter=/*/*/ModelAliasTests*/* executed=76 passed=76 failed=0 skipped=0 trx=/work/worktrees/task-818582a5/.antiphon/c959-second-final/20261003-191547-0744/rows/CP-7/run.trx slot=granted waited=0s dirty=0 source=3ccc171bdaedffaf48838dfa744c6129d82c06ef sourceState=clean buildSource=verified
PHASES CP-7 slotWait=0s build=95.1122728s startup=4.636576s testsWall=0.1249603s teardown=0.7745254s hostWall=5.5360622s
CHECKPOINT CP-8 commit=3ccc171bdaedffaf48838dfa744c6129d82c06ef build=ok filter=/*/*/*/*[Category=Unit] executed=3961 passed=3961 failed=0 skipped=33 trx=/work/worktrees/task-818582a5/.antiphon/c959-second-final/20261003-191547-0744/rows/CP-8/run.trx slot=granted waited=0s dirty=0 source=3ccc171bdaedffaf48838dfa744c6129d82c06ef sourceState=clean buildSource=verified
PHASES CP-8 slotWait=0s build=96.4923494s startup=93.9263504s testsWall=374.9269199s teardown=2.3285055s hostWall=471.181776s
SLOW CLASS Antiphon.Tests.Scripts.RemoteScriptContractTests 110s tests=84 (CP-8)
SLOW CLASS Antiphon.Tests.TestHelpers.TestClassificationPolicyTests 68s tests=25 (CP-8)
unlisted: none (the tool ran no other build or test command)
wall: 19m33s  sequential-equivalent: 11m14s  builds: 8  max-concurrent-builds: 1  rows: 6 green 0 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/, bin-c959-unit/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-191547-0744
evidence: /work/worktrees/task-818582a5/.antiphon/c959-second-final/20261003-191547-0744/report.md
verdict: GREEN exit=0
