--- checkpoint report ---
run: 20261003-173834-80cb   manifest: /work/worktrees/task-d0491157/.antiphon/checkpoints/20261003-173834-80cb/manifest.resolved.yaml
commit: 73e4fede0b41d3be71cbb8146b9ed1231119f286  branch: feat/card-task-d0491157  worktree: /work/worktrees/task-d0491157  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 73e4fede0b41d3be71cbb8146b9ed1231119f286 state=clean buildSource=verified
CHECKPOINT CP-2 commit=73e4fede0b41d3be71cbb8146b9ed1231119f286 build=ok filter=/*/*/(GrokSignInPromptDetectorTests*)|(GrokLinuxBlockingPromptTests*)/C1006_* executed=12 passed=12 failed=0 skipped=0 trx=/work/worktrees/task-d0491157/.antiphon/checkpoints/20261003-173834-80cb/rows/CP-2/run.trx slot=granted waited=30s dirty=0 source=73e4fede0b41d3be71cbb8146b9ed1231119f286 sourceState=clean buildSource=verified
PHASES CP-2 slotWait=30s build=188.9768175s startup=4.7243013s testsWall=0.1600876s teardown=0.6669177s hostWall=5.5513131s
CHECKPOINT CP-3 commit=73e4fede0b41d3be71cbb8146b9ed1231119f286 build=ok filter=/*/*/(GrokSignInPromptDetectorTests*)|(GrokTrustPromptDetectorTests*)|(GrokStartupReadinessTests*)|(GrokLinuxStartupReadinessTests*)/* executed=47 passed=47 failed=0 skipped=0 trx=/work/worktrees/task-d0491157/.antiphon/checkpoints/20261003-173834-80cb/rows/CP-3/run.trx slot=granted waited=0s dirty=0 source=73e4fede0b41d3be71cbb8146b9ed1231119f286 sourceState=clean buildSource=verified
PHASES CP-3 slotWait=45s build=160.5945919s startup=4.3149601s testsWall=0.2326807s teardown=0.5861933s hostWall=5.1338342s
CHECKPOINT CP-4 commit=73e4fede0b41d3be71cbb8146b9ed1231119f286 build=ok filter=/*/*/(RunnerGrokAdapterReadyTests*)|(RunnerGrokAdapterSignInPromptTests*)|(RunnerGrokAdapterTrustPromptTests*)|(GrokStartupCaptureStoreTests*)/* executed=25 passed=25 failed=0 skipped=0 trx=/work/worktrees/task-d0491157/.antiphon/checkpoints/20261003-173834-80cb/rows/CP-4/run.trx slot=granted waited=0s dirty=0 source=73e4fede0b41d3be71cbb8146b9ed1231119f286 sourceState=clean buildSource=verified
PHASES CP-4 slotWait=0s build=124.9561777s startup=3.2430001s testsWall=5.2977286s teardown=0.7945366s hostWall=9.3352654s
unlisted: none (the tool ran no other build or test command)
wall: 9m31s  sequential-equivalent: 0m51s  builds: 5  max-concurrent-builds: 1  rows: 3 green 0 red 0 skipped
outputs: deleted bin-c1006-red/, bin-c1006-blockers/, bin-c1006-regression/, bin-c1006-adapters/, bin-c1006-windows/
evidence: /work/worktrees/task-d0491157/.antiphon/checkpoints/20261003-173834-80cb/report.md
verdict: GREEN exit=0
