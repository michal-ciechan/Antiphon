--- checkpoint report ---
run: 20261003-165542-31db   manifest: /work/worktrees/task-d0491157/.antiphon/checkpoints/20261003-165542-31db/manifest.resolved.yaml
commit: 98afc108e85925eca1ec511d149dd691f5030797  branch: feat/card-task-d0491157  worktree: /work/worktrees/task-d0491157  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 98afc108e85925eca1ec511d149dd691f5030797 state=clean buildSource=verified
CHECKPOINT CP-2 commit=98afc108e85925eca1ec511d149dd691f5030797 build=ok filter=/*/*/(GrokSignInPromptDetectorTests*)|(GrokLinuxBlockingPromptTests*)/C1006_* executed=12 passed=11 failed=1 skipped=0 trx=/work/worktrees/task-d0491157/.antiphon/checkpoints/20261003-165542-31db/rows/CP-2/run.trx slot=granted waited=0s dirty=0 source=98afc108e85925eca1ec511d149dd691f5030797 sourceState=clean buildSource=verified
PHASES CP-2 slotWait=0s build=138.3094135s startup=4.6721577s testsWall=0.1763435s teardown=0.5014035s hostWall=5.3499168s
FAILED Antiphon.Tests.Agents.GrokLinuxBlockingPromptTests.C1006_Windows_fixture_results_are_unchanged (CP-2) ShouldAssertException: counts.Order()     should be [2, 44, 68]     but was [0, 2, 44, 68]     difference [*0*, *2*, *44*, *68*] -> rows/CP-2/failures.md
unlisted: none (the tool ran no other build or test command)
wall: 2m24s  sequential-equivalent: 0m05s  builds: 5  max-concurrent-builds: 1  rows: 0 green 1 red 0 skipped
outputs: kept bin-c1006-red/, bin-c1006-blockers/, bin-c1006-regression/, bin-c1006-adapters/, bin-c1006-windows/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-165542-31db
evidence: /work/worktrees/task-d0491157/.antiphon/checkpoints/20261003-165542-31db/report.md
verdict: RED exit=1
