--- checkpoint report ---
run: 20261003-170037-2261   manifest: /work/worktrees/task-d0491157/.antiphon/checkpoints/20261003-170037-2261/manifest.resolved.yaml
commit: 33b0a1c85402f29450da7b3e01f422ad4a3da57d  branch: feat/card-task-d0491157  worktree: /work/worktrees/task-d0491157  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 33b0a1c85402f29450da7b3e01f422ad4a3da57d state=clean buildSource=verified
CHECKPOINT CP-2 commit=33b0a1c85402f29450da7b3e01f422ad4a3da57d build=ok filter=/*/*/(GrokSignInPromptDetectorTests*)|(GrokLinuxBlockingPromptTests*)/C1006_* executed=12 passed=12 failed=0 skipped=0 trx=/work/worktrees/task-d0491157/.antiphon/checkpoints/20261003-170037-2261/rows/CP-2/run.trx slot=granted waited=0s dirty=0 source=33b0a1c85402f29450da7b3e01f422ad4a3da57d sourceState=clean buildSource=verified
PHASES CP-2 slotWait=0s build=261.9805072s startup=5.3390257s testsWall=0.3307606s teardown=0.8390775s hostWall=6.5088874s
CHECKPOINT CP-3 commit=33b0a1c85402f29450da7b3e01f422ad4a3da57d build=ok filter=/*/*/(GrokSignInPromptDetectorTests*)|(GrokTrustPromptDetectorTests*)|(GrokStartupReadinessTests*)|(GrokLinuxStartupReadinessTests*)/* executed=47 passed=47 failed=0 skipped=0 trx=/work/worktrees/task-d0491157/.antiphon/checkpoints/20261003-170037-2261/rows/CP-3/run.trx slot=granted waited=0s dirty=0 source=33b0a1c85402f29450da7b3e01f422ad4a3da57d sourceState=clean buildSource=verified
PHASES CP-3 slotWait=0s build=196.4907084s startup=4.2738292s testsWall=0.4022635s teardown=0.6160076s hostWall=5.2921005s
CHECKPOINT CP-4 commit=33b0a1c85402f29450da7b3e01f422ad4a3da57d build=ok filter=/*/*/(RunnerGrokAdapterReadyTests*)|(RunnerGrokAdapterSignInPromptTests*)|(RunnerGrokAdapterTrustPromptTests*)|(GrokStartupCaptureStoreTests*)/* executed=25 passed=25 failed=0 skipped=0 trx=/work/worktrees/task-d0491157/.antiphon/checkpoints/20261003-170037-2261/rows/CP-4/run.trx slot=granted waited=0s dirty=0 source=33b0a1c85402f29450da7b3e01f422ad4a3da57d sourceState=clean buildSource=verified
PHASES CP-4 slotWait=0s build=144.7925567s startup=4.5870248s testsWall=5.2817294s teardown=0.6439601s hostWall=10.5127144s
unlisted: none (the tool ran no other build or test command)
wall: 10m29s  sequential-equivalent: 0m23s  builds: 5  max-concurrent-builds: 1  rows: 3 green 0 red 0 skipped
outputs: kept bin-c1006-red/, bin-c1006-blockers/, bin-c1006-regression/, bin-c1006-adapters/, bin-c1006-windows/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-170037-2261
evidence: /work/worktrees/task-d0491157/.antiphon/checkpoints/20261003-170037-2261/report.md
verdict: GREEN exit=0
