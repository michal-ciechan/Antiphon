--- checkpoint report ---
run: 20261003-165203-f5d7   manifest: /work/worktrees/task-d0491157/.antiphon/checkpoints/20261003-165203-f5d7/manifest.resolved.yaml
commit: dfc5bc7baddd20ab11758832e5f5d9600708140d  branch: feat/card-task-d0491157  worktree: /work/worktrees/task-d0491157  host: Debian GNU/Linux 12 (bookworm) cores=24
source: dfc5bc7baddd20ab11758832e5f5d9600708140d state=clean buildSource=unknown
CHECKPOINT CP-2 commit=dfc5bc7baddd20ab11758832e5f5d9600708140d build=failed filter=/*/*/(GrokSignInPromptDetectorTests*)|(GrokLinuxBlockingPromptTests*)/C1006_* executed=n/a passed=n/a failed=n/a skipped=n/a trx=n/a slot=skipped waited=0s dirty=0 source=dfc5bc7baddd20ab11758832e5f5d9600708140d sourceState=clean buildSource=unknown
unlisted: none (the tool ran no other build or test command)
wall: 1m37s  sequential-equivalent: 0m00s  builds: 5  max-concurrent-builds: 1  rows: 0 green 1 red 0 skipped
outputs: kept bin-c1006-red/, bin-c1006-blockers/, bin-c1006-regression/, bin-c1006-adapters/, bin-c1006-windows/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-165203-f5d7
evidence: /work/worktrees/task-d0491157/.antiphon/checkpoints/20261003-165203-f5d7/report.md
verdict: RED exit=2
