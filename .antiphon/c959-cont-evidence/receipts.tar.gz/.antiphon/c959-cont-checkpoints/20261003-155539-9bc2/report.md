--- checkpoint report ---
run: 20261003-155539-9bc2   manifest: /work/worktrees/task-1a73906f/.antiphon/c959-cont-checkpoints/20261003-155539-9bc2/manifest.resolved.yaml
commit: 3164b88459469d5e1f6fd9b1e2653670d9e0671e  branch: feat/card-task-1a73906f  worktree: /work/worktrees/task-1a73906f  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 3164b88459469d5e1f6fd9b1e2653670d9e0671e state=clean buildSource=unknown
CHECKPOINT CP-4 commit=3164b88459469d5e1f6fd9b1e2653670d9e0671e build=failed filter=/*/*/CodexCliAdmissionTests*/C959_* executed=n/a passed=n/a failed=n/a skipped=n/a trx=n/a slot=skipped waited=0s dirty=0 source=3164b88459469d5e1f6fd9b1e2653670d9e0671e sourceState=clean buildSource=unknown
unlisted: none (the tool ran no other build or test command)
wall: 2m05s  sequential-equivalent: 0m00s  builds: 7  max-concurrent-builds: 1  rows: 0 green 1 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-155539-9bc2
evidence: /work/worktrees/task-1a73906f/.antiphon/c959-cont-checkpoints/20261003-155539-9bc2/report.md
verdict: RED exit=2
