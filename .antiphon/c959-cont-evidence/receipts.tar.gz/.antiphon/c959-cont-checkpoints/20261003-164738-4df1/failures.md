## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Exact_profile_model_wins
outcome: Failed
durationSeconds: 0.6663511
baseline: n/a
message:
ShouldAssertException: await CodeAsync(k.Service.CreateAsync(k.Request(false) with { AgentId = profileless }, k.Caller, CancellationToken.None))
    should be
"codex_cli_version_too_old"
    but was
null

Additional Info:
    C959-v18-profileless-actual-model
stack:
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Exact_profile_model_wins() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 230
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Exact_profile_model_wins() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 230
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Exact_profile_model_wins" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Exact_profile_model_wins"

## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner
outcome: Failed
durationSeconds: 3.1706181
baseline: n/a
message:
ShouldAssertException: queued.Body
    should contain (case insensitive comparison)
"C959 delivery α
second line
END-C959"
    but was actually
"[antiphon-task:4d3e516d] role=Docs tier=High workspace=Worktree C959 delivery α second line END-C959..."

Additional Info:
    C959-pc-187
stack:
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 348
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 350
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 350
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Compatible_launch_keeps_model_and_runner" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Compatible_launch_keeps_model_and_runner"

