--- checkpoint report ---
run: 20261003-164738-4df1   manifest: /work/worktrees/task-1a73906f/.antiphon/c959-cont-checkpoints/20261003-164738-4df1/manifest.resolved.yaml
commit: 42256d12c2b90c3a2144e03d46b700e33ada5620  branch: feat/card-task-1a73906f  worktree: /work/worktrees/task-1a73906f  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 42256d12c2b90c3a2144e03d46b700e33ada5620 state=clean buildSource=verified
CHECKPOINT CP-4 commit=42256d12c2b90c3a2144e03d46b700e33ada5620 build=ok filter=/*/*/CodexCliAdmissionTests*/C959_* executed=9 passed=7 failed=2 skipped=0 trx=/work/worktrees/task-1a73906f/.antiphon/c959-cont-checkpoints/20261003-164738-4df1/rows/CP-4/run.trx slot=granted waited=0s dirty=0 source=42256d12c2b90c3a2144e03d46b700e33ada5620 sourceState=clean buildSource=verified
PHASES CP-4 slotWait=0s build=96.9857866s startup=48.2382281s testsWall=30.3647069s teardown=1.4971352s hostWall=80.1000642s
FAILED Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Exact_profile_model_wins (CP-4) ShouldAssertException: await CodeAsync(k.Service.CreateAsync(k.Request(false) with { AgentId = profileless }, k.Caller, CancellationToken.None))     should be "codex_cli_version_too_old"     but was null  Additional Info:     C959-v18-profileless-actual-model -> rows/CP-4/failures.md
FAILED Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner (CP-4) ShouldAssertException: queued.Body     should contain (case insensitive comparison) "C959 delivery α second line END-C959"     but was actually "[antiphon-task:4d3e516d] role=Docs tier=High workspace=Worktree C959 delivery α second line END-C959..."  Additional Info:     C959-pc-187 -> rows/CP-4/failures.md
unlisted: none (the tool ran no other build or test command)
wall: 2m58s  sequential-equivalent: 1m20s  builds: 7  max-concurrent-builds: 1  rows: 0 green 1 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-164738-4df1
evidence: /work/worktrees/task-1a73906f/.antiphon/c959-cont-checkpoints/20261003-164738-4df1/report.md
verdict: RED exit=1
