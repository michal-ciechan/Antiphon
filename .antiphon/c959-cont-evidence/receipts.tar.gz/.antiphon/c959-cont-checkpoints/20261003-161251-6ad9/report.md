--- checkpoint report ---
run: 20261003-161251-6ad9   manifest: /work/worktrees/task-1a73906f/.antiphon/c959-cont-checkpoints/20261003-161251-6ad9/manifest.resolved.yaml
commit: 9e8687c224cbb140cf169343c531e2d06853d48e  branch: feat/card-task-1a73906f  worktree: /work/worktrees/task-1a73906f  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 9e8687c224cbb140cf169343c531e2d06853d48e state=clean buildSource=verified
CHECKPOINT CP-4 commit=9e8687c224cbb140cf169343c531e2d06853d48e build=ok filter=/*/*/CodexCliAdmissionTests*/C959_* executed=9 passed=7 failed=2 skipped=0 trx=/work/worktrees/task-1a73906f/.antiphon/c959-cont-checkpoints/20261003-161251-6ad9/rows/CP-4/run.trx slot=granted waited=0s dirty=0 source=9e8687c224cbb140cf169343c531e2d06853d48e sourceState=clean buildSource=verified
PHASES CP-4 slotWait=0s build=89.2912976s startup=43.6687288s testsWall=22.955172s teardown=2.4806567s hostWall=69.1045771s
FAILED Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Override_is_scoped_expiring_and_audited (CP-4) ShouldAssertException: new DelegationSettingsValidator(k.Clock).Validate(null, k.Settings).Failed     should be True     but was False  Additional Info:     C959-v20-invalid model -> rows/CP-4/failures.md
FAILED Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner (CP-4) ShouldAssertException: queued.Body     should contain (case insensitive comparison) "C959 delivery α second line END-C959"     but was actually "[antiphon-task:23278ab5] role=Docs tier=High workspace=Shared C959 delivery α [antiphon-task:23278ab..."  Additional Info:     C959-pc-187 -> rows/CP-4/failures.md
CHECKPOINT CP-5 commit=9e8687c224cbb140cf169343c531e2d06853d48e build=ok filter=/*/*/(CodexPhoneHomeCreateTests*)|(PinnedCodexProfileDispatchLaunchTests*)|(ModelAvailabilityCreateTests*)|(ModelAvailabilityDispatcherTests*)/* executed=22 passed=22 failed=0 skipped=0 trx=/work/worktrees/task-1a73906f/.antiphon/c959-cont-checkpoints/20261003-161251-6ad9/rows/CP-5/run.trx slot=granted waited=0s dirty=0 source=9e8687c224cbb140cf169343c531e2d06853d48e sourceState=clean buildSource=verified
PHASES CP-5 slotWait=0s build=108.0282478s startup=41.2007925s testsWall=22.5580115s teardown=1.3127365s hostWall=65.0715403s
unlisted: none (the tool ran no other build or test command)
wall: 5m34s  sequential-equivalent: 2m15s  builds: 7  max-concurrent-builds: 1  rows: 1 green 1 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-161251-6ad9
evidence: /work/worktrees/task-1a73906f/.antiphon/c959-cont-checkpoints/20261003-161251-6ad9/report.md
verdict: RED exit=1
