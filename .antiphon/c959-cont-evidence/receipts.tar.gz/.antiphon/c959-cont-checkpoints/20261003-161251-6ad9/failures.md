## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Override_is_scoped_expiring_and_audited
outcome: Failed
durationSeconds: 0.4587167
baseline: n/a
message:
ShouldAssertException: new DelegationSettingsValidator(k.Clock).Validate(null, k.Settings).Failed
    should be
True
    but was
False

Additional Info:
    C959-v20-invalid model
stack:
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Override_is_scoped_expiring_and_audited() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 246
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Override_is_scoped_expiring_and_audited() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 241
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Override_is_scoped_expiring_and_audited" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Override_is_scoped_expiring_and_audited"

## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner
outcome: Failed
durationSeconds: 5.6655702
baseline: n/a
message:
ShouldAssertException: queued.Body
    should contain (case insensitive comparison)
"C959 delivery α
second line
END-C959"
    but was actually
"[antiphon-task:23278ab5] role=Docs tier=High workspace=Shared C959 delivery α [antiphon-task:23278ab..."

Additional Info:
    C959-pc-187
stack:
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 276
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 278
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 278
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Compatible_launch_keeps_model_and_runner" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Compatible_launch_keeps_model_and_runner"

