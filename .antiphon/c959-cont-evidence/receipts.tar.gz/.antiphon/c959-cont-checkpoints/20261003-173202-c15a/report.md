--- checkpoint report ---
run: 20261003-173202-c15a   manifest: /work/worktrees/task-1a73906f/.antiphon/c959-cont-checkpoints/20261003-173202-c15a/manifest.resolved.yaml
commit: b8f12606294e57532a3d7eb759295f9926236e29  branch: feat/card-task-1a73906f  worktree: /work/worktrees/task-1a73906f  host: Debian GNU/Linux 12 (bookworm) cores=24
source: b8f12606294e57532a3d7eb759295f9926236e29 state=clean buildSource=verified
CHECKPOINT CP-3 commit=b8f12606294e57532a3d7eb759295f9926236e29 build=ok filter=/*/*/RunnerCodexCliEvidenceTests*/C959_* executed=5 passed=5 failed=0 skipped=0 trx=/work/worktrees/task-1a73906f/.antiphon/c959-cont-checkpoints/20261003-173202-c15a/rows/CP-3/run.trx slot=granted waited=0s dirty=0 source=b8f12606294e57532a3d7eb759295f9926236e29 sourceState=clean buildSource=verified
PHASES CP-3 slotWait=0s build=123.1815785s startup=6.7916066s testsWall=15.6176811s teardown=1.5264707s hostWall=23.935785s
unlisted: none (the tool ran no other build or test command)
wall: 3m08s  sequential-equivalent: 0m24s  builds: 7  max-concurrent-builds: 1  rows: 1 green 0 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-173202-c15a
evidence: /work/worktrees/task-1a73906f/.antiphon/c959-cont-checkpoints/20261003-173202-c15a/report.md
verdict: GREEN exit=0
