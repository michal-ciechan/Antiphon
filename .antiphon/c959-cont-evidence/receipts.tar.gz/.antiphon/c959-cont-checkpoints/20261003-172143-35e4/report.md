--- checkpoint report ---
run: 20261003-172143-35e4   manifest: /work/worktrees/task-1a73906f/.antiphon/c959-cont-checkpoints/20261003-172143-35e4/manifest.resolved.yaml
commit: c443a6e1e150d85ae828c933e822c15f6a83d0f3  branch: feat/card-task-1a73906f  worktree: /work/worktrees/task-1a73906f  host: Debian GNU/Linux 12 (bookworm) cores=24
source: c443a6e1e150d85ae828c933e822c15f6a83d0f3 state=clean buildSource=verified
CHECKPOINT CP-3 commit=c443a6e1e150d85ae828c933e822c15f6a83d0f3 build=ok filter=/*/*/RunnerCodexCliEvidenceTests*/C959_* executed=5 passed=5 failed=0 skipped=0 trx=/work/worktrees/task-1a73906f/.antiphon/c959-cont-checkpoints/20261003-172143-35e4/rows/CP-3/run.trx slot=granted waited=0s dirty=0 source=c443a6e1e150d85ae828c933e822c15f6a83d0f3 sourceState=clean buildSource=verified
PHASES CP-3 slotWait=0s build=91.3906634s startup=4.7157455s testsWall=7.8399392s teardown=0.5067607s hostWall=13.0627474s
unlisted: none (the tool ran no other build or test command)
wall: 1m45s  sequential-equivalent: 0m13s  builds: 7  max-concurrent-builds: 1  rows: 1 green 0 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-172143-35e4
evidence: /work/worktrees/task-1a73906f/.antiphon/c959-cont-checkpoints/20261003-172143-35e4/report.md
verdict: GREEN exit=0
