## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Create_refuses_bad_versions
outcome: Failed
durationSeconds: 2.6080313
baseline: n/a
message:
ShouldAssertException: failure?.Code
    should be
"codex_cli_version_too_old"
    but was
null

Additional Info:
    C959-v15-code False/0.156.1/
stack:
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Create_refuses_bad_versions() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 80
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Create_refuses_bad_versions() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 91
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Create_refuses_bad_versions" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Create_refuses_bad_versions"

## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Existing_refusals_and_flags_keep_precedence
outcome: Failed
durationSeconds: 0.4180625
baseline: n/a
message:
ShouldAssertException: await CodeAsync(k.Service.CreateAsync(request, k.Caller, CancellationToken.None))
    should be
"codex_cli_version_too_old"
    but was
null

Additional Info:
    C959-pc-137
stack:
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Existing_refusals_and_flags_keep_precedence() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 104
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Existing_refusals_and_flags_keep_precedence() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 120
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Existing_refusals_and_flags_keep_precedence" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Existing_refusals_and_flags_keep_precedence"

## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Queued_downgrade_blocks_before_claim
outcome: Failed
durationSeconds: 8.4471496
baseline: n/a
message:
ShouldAssertException: task.Status
    should be
AgentTaskStatus.Blocked
    but was
AgentTaskStatus.Dispatched

Additional Info:
    C959-v17-blocked
stack:
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Queued_downgrade_blocks_before_claim() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 140
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Queued_downgrade_blocks_before_claim() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 149
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Queued_downgrade_blocks_before_claim() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 149
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Queued_downgrade_blocks_before_claim" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Queued_downgrade_blocks_before_claim"

## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Exact_profile_model_wins
outcome: Failed
durationSeconds: 0.8243097
baseline: n/a
message:
ShouldAssertException: await CodeAsync(k.Service.CreateAsync(k.Request(false) with { AgentId = id }, k.Caller, CancellationToken.None))
    should be
"codex_cli_version_too_old"
    but was
null

Additional Info:
    C959-pc-147
stack:
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Exact_profile_model_wins() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 165
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Exact_profile_model_wins() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 183
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Exact_profile_model_wins" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Exact_profile_model_wins"

## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Profile_launcher_uses_its_own_evidence
outcome: Failed
durationSeconds: 0.3213913
baseline: n/a
message:
ShouldAssertException: await CodeAsync(k.Service.CreateAsync(k.Request(false) with { AgentId = id }, k.Caller, CancellationToken.None))
    should be
"codex_cli_version_too_old"
    but was
null

Additional Info:
    C959-pc-153
stack:
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Profile_launcher_uses_its_own_evidence() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 192
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Profile_launcher_uses_its_own_evidence() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 205
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Profile_launcher_uses_its_own_evidence" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Profile_launcher_uses_its_own_evidence"

## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Override_is_scoped_expiring_and_audited
outcome: Failed
durationSeconds: 0.0087917
baseline: n/a
message:
ShouldAssertException: member
    should not be null but was

Additional Info:
    C959-v20-scope operator setting must exist
stack:
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Override_is_scoped_expiring_and_audited() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 212
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Override_is_scoped_expiring_and_audited" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Override_is_scoped_expiring_and_audited"

## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner
outcome: Failed
durationSeconds: 0.4869667
baseline: n/a
message:
ShouldAssertException: await CodeAsync(refused.CreateAsync())
    should not be null but was

Additional Info:
    C959-v21-admission-before-delivery
stack:
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 256
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 257
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Compatible_launch_keeps_model_and_runner" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Compatible_launch_keeps_model_and_runner"

## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Retry_and_cancellation_recheck
outcome: Failed
durationSeconds: 0.6123795
baseline: n/a
message:
ShouldAssertException: await CodeAsync(k.Service.RetryAsync(task.Id, CancellationToken.None))
    should be
"codex_cli_version_too_old"
    but was
null

Additional Info:
    C959-pc-193
stack:
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Retry_and_cancellation_recheck() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 291
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Retry_and_cancellation_recheck() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 303
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:
[testcontainers.org 00:00:48.78] Delete Docker container 32a1ef86da35

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Retry_and_cancellation_recheck" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Retry_and_cancellation_recheck"

