## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Create_refuses_bad_versions
outcome: Failed
durationSeconds: 1.8004705
baseline: n/a
message:
NullReferenceException: Object reference not set to an instance of an object.
stack:
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Create_refuses_bad_versions() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 83
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Create_refuses_bad_versions() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 91
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Create_refuses_bad_versions" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Create_refuses_bad_versions"

## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Existing_refusals_and_flags_keep_precedence
outcome: Failed
durationSeconds: 0.4742046
baseline: n/a
message:
ShouldAssertException: (await FailureAsync(k.Service.CreateAsync(request, k.Caller, CancellationToken.None)))
            ?.Code
    should be
"codex_cli_version_too_old"
    but was
"validation_failed"
    difference
Difference     |  |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |        
               | \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/       
Index          | 0    1    2    3    4    5    6    7    8    9    10   11   12   13   14   15   16   17   18   19   20   ...  
Expected Value | c    o    d    e    x    _    c    l    i    _    v    e    r    s    i    o    n    _    t    o    o    ...  
Actual Value   | v    a    l    i    d    a    t    i    o    n    _    f    a    i    l    e    d                        ...  
Expected Code  | 99   111  100  101  120  95   99   108  105  95   118  101  114  115  105  111  110  95   116  111  111  ...  
Actual Code    | 118  97   108  105  100  97   116  105  111  110  95   102  97   105  108  101  100                      ...  

Difference     |       |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |    |   
               |      \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  \|/  
Index          | ...  4    5    6    7    8    9    10   11   12   13   14   15   16   17   18   19   20   21   22   23   24   
Expected Value | ...  x    _    c    l    i    _    v    e    r    s    i    o    n    _    t    o    o    _    o    l    d    
Actual Value   | ...  d    a    t    i    o    n    _    f    a    i    l    e    d                                            
Expected Code  | ...  120  95   99   108  105  95   118  101  114  115  105  111  110  95   116  111  111  95   111  108  100  
Actual Code    | ...  100  97   116  105  111  110  95   102  97   105  108  101  100                                          

Additional Info:
    C959-pc-137
stack:
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Existing_refusals_and_flags_keep_precedence() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 105
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Existing_refusals_and_flags_keep_precedence() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 125
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Existing_refusals_and_flags_keep_precedence" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Existing_refusals_and_flags_keep_precedence"

## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Queued_downgrade_blocks_before_claim
outcome: Failed
durationSeconds: 10.0262593
baseline: n/a
message:
ShouldAssertException: task.Status
    should be
AgentTaskStatus.Blocked
    but was
AgentTaskStatus.Dispatched

Additional Info:
    C959-v17-blocked
stack:
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Queued_downgrade_blocks_before_claim() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 145
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Queued_downgrade_blocks_before_claim() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 154
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Queued_downgrade_blocks_before_claim() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 154
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Queued_downgrade_blocks_before_claim" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Queued_downgrade_blocks_before_claim"

## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Profile_launcher_uses_its_own_evidence
outcome: Failed
durationSeconds: 0.3920634
baseline: n/a
message:
InvalidOperationException: Sequence contains no elements
stack:
   at System.Linq.ThrowHelper.ThrowNoElementsException()
   at System.Linq.Enumerable.Single[TSource](IEnumerable`1 source)
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Profile_launcher_uses_its_own_evidence() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 201
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Profile_launcher_uses_its_own_evidence() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 213
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Profile_launcher_uses_its_own_evidence" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Profile_launcher_uses_its_own_evidence"

## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Override_is_scoped_expiring_and_audited
outcome: Failed
durationSeconds: 0.0120951
baseline: n/a
message:
ShouldAssertException: member
    should not be null but was

Additional Info:
    C959-v20-scope operator setting must exist
stack:
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Override_is_scoped_expiring_and_audited() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 221
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Override_is_scoped_expiring_and_audited" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Override_is_scoped_expiring_and_audited"

## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner
outcome: Failed
durationSeconds: 0.8125857
baseline: n/a
message:
ShouldAssertException: await FailureAsync(refused.CreateAsync())
    should not be null but was

Additional Info:
    C959-v21-admission-before-delivery
stack:
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 267
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 268
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Compatible_launch_keeps_model_and_runner" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Compatible_launch_keeps_model_and_runner"

## Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Retry_and_cancellation_recheck
outcome: Failed
durationSeconds: 0.721989
baseline: n/a
message:
ShouldAssertException: task.Status
    should be
AgentTaskStatus.Failed
    but was
AgentTaskStatus.Queued

Additional Info:
    C959-v22-state
stack:
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Retry_and_cancellation_recheck() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 304
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Retry_and_cancellation_recheck() in /work/worktrees/task-1a73906f/tests/Antiphon.Tests/Application/CodexCliAdmissionTests.cs:line 314
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   at System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw()
   at System.Runtime.CompilerServices.TaskAwaiter.ThrowForNonSuccess(Task task)
   at System.Runtime.CompilerServices.TaskAwaiter.HandleNonSuccessAndDebuggerNotification(Task task, ConfigureAwaitOptions options)
   --- TUnit internals omitted (run with --detailed-stacktrace for full trace) ---
stdout:
[testcontainers.org 00:00:50.04] Delete Docker container 58f3a6302334

rerun:
dotnet run --project tools/Antiphon.Checkpoints -- row --name CP-4 --project tests/Antiphon.Tests --output-path bin-c959-admission/ --filter "/*/*/CodexCliAdmissionTests/C959_Retry_and_cancellation_recheck" --no-build
dotnet run --project tests/Antiphon.Tests --no-build --property:OutputPath=bin-c959-admission/ -- --treenode-filter "/*/*/CodexCliAdmissionTests/C959_Retry_and_cancellation_recheck"

