--- checkpoint report ---
run: 20261003-164326-e9ce   manifest: /work/worktrees/task-1a73906f/.antiphon/c959-cont-checkpoints/20261003-164326-e9ce/manifest.resolved.yaml
commit: f7589a03e94c735b4609ec65dc5d882f33303584  branch: feat/card-task-1a73906f  worktree: /work/worktrees/task-1a73906f  host: Debian GNU/Linux 12 (bookworm) cores=24
source: f7589a03e94c735b4609ec65dc5d882f33303584 state=clean buildSource=verified
CHECKPOINT CP-4 commit=f7589a03e94c735b4609ec65dc5d882f33303584 build=ok filter=/*/*/CodexCliAdmissionTests*/C959_* executed=9 passed=6 failed=3 skipped=0 trx=/work/worktrees/task-1a73906f/.antiphon/c959-cont-checkpoints/20261003-164326-e9ce/rows/CP-4/run.trx slot=granted waited=0s dirty=0 source=f7589a03e94c735b4609ec65dc5d882f33303584 sourceState=clean buildSource=verified
PHASES CP-4 slotWait=0s build=98.834914s startup=40.428754s testsWall=23.1465916s teardown=1.1995757s hostWall=64.7749634s
FAILED Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Queued_downgrade_blocks_before_claim (CP-4) ShouldAssertException: row.Status     should be AgentTaskStatus.Blocked     but was AgentTaskStatus.Failed  Additional Info:     C959-v17-late-downgrade-blocked -> rows/CP-4/failures.md
FAILED Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Exact_profile_model_wins (CP-4) DbUpdateException: An error occurred while saving the entity changes. See the inner exception for details. -> rows/CP-4/failures.md
FAILED Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Compatible_launch_keeps_model_and_runner (CP-4) ShouldAssertException: k.Factory.Created.Count     should be 1     but was 0  Additional Info:     C959-pc-190 -> rows/CP-4/failures.md
unlisted: none (the tool ran no other build or test command)
wall: 2m45s  sequential-equivalent: 1m05s  builds: 7  max-concurrent-builds: 1  rows: 0 green 1 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-164326-e9ce
evidence: /work/worktrees/task-1a73906f/.antiphon/c959-cont-checkpoints/20261003-164326-e9ce/report.md
verdict: RED exit=1
