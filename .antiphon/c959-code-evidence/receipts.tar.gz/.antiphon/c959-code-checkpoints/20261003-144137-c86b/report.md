--- checkpoint report ---
run: 20261003-144137-c86b   manifest: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-144137-c86b/manifest.resolved.yaml
commit: 55ba0b32adf6bb75a68bd765c1004ea606da408c  branch: feat/card-task-b5228641  worktree: /work/worktrees/task-b5228641  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 55ba0b32adf6bb75a68bd765c1004ea606da408c state=clean buildSource=verified
CHECKPOINT CP-3 commit=55ba0b32adf6bb75a68bd765c1004ea606da408c build=ok filter=/*/*/RunnerCodexCliEvidenceTests*/C959_* executed=5 passed=0 failed=5 skipped=0 trx=/work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-144137-c86b/rows/CP-3/run.trx slot=granted waited=0s dirty=0 source=55ba0b32adf6bb75a68bd765c1004ea606da408c sourceState=clean buildSource=verified
PHASES CP-3 slotWait=0s build=103.1836467s startup=6.7535285s testsWall=3.1314312s teardown=0.9326901s hostWall=10.8176712s
FAILED Antiphon.Tests.Application.RunnerCodexCliEvidenceTests.C959_Heartbeat_updates_only_probe_evidence (CP-3) ShouldAssertException: Text(status, "codexCliVersion")     should be "0.160.0"     but was null  Additional Info:     C959-v09-newer -> rows/CP-3/failures.md
FAILED Antiphon.Tests.Application.RunnerCodexCliEvidenceTests.C959_Freshness_boundaries (CP-3) ShouldAssertException: Flag(Shape(host.Directory.Status(host.AllowedRunnerId)), "codexCliVersionStale")     should be False     but was null  Additional Info:     C959-pc-200 -> rows/CP-3/failures.md
FAILED Antiphon.Tests.Application.RunnerCodexCliEvidenceTests.C959_Generation_change_clears_version (CP-3) ShouldAssertException: descriptor!.Capabilities!.CodexCliVersion     should be null but was "0.160.0"  Additional Info:     C959-v11-register-clear -> rows/CP-3/failures.md
FAILED Antiphon.Tests.Application.RunnerCodexCliEvidenceTests.C959_Catalogue_and_status_project_version (CP-3) ShouldAssertException: Text(desktop, "codexCliVersion")     should be "0.159.1"     but was null  Additional Info:     C959-v12-desktop -> rows/CP-3/failures.md
FAILED Antiphon.Tests.Application.RunnerCodexCliEvidenceTests.C959_Exact_probe_transport_is_bound (CP-3) ShouldAssertException: sample?.CodexCliVersion     should be "0.159.1"     but was null  Additional Info:     C959-v13-phone-home -> rows/CP-3/failures.md
unlisted: none (the tool ran no other build or test command)
wall: 1m56s  sequential-equivalent: 0m11s  builds: 7  max-concurrent-builds: 1  rows: 0 green 1 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-144137-c86b
evidence: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-144137-c86b/report.md
verdict: RED exit=1
