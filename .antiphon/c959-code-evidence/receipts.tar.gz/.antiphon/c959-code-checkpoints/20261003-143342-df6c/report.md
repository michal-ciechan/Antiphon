--- checkpoint report ---
run: 20261003-143342-df6c   manifest: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-143342-df6c/manifest.resolved.yaml
commit: 201cdb07190ea515b1057e5284fcd820d031b701  branch: feat/card-task-b5228641  worktree: /work/worktrees/task-b5228641  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 201cdb07190ea515b1057e5284fcd820d031b701 state=clean buildSource=verified
CHECKPOINT CP-1 commit=201cdb07190ea515b1057e5284fcd820d031b701 build=ok filter=/*/*/CodexCliVersionProbeTests*/C959_* executed=5 passed=5 failed=0 skipped=0 trx=/work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-143342-df6c/rows/CP-1/run.trx slot=granted waited=0s dirty=0 source=201cdb07190ea515b1057e5284fcd820d031b701 sourceState=clean buildSource=verified
PHASES CP-1 slotWait=0s build=17.2786696s startup=2.5854199s testsWall=66.2813381s teardown=0.5765869s hostWall=69.4433463s
SLOW CLASS Antiphon.SessionRunner.Tests.CodexCliVersionProbeTests 66s tests=5 (CP-1)
unlisted: none (the tool ran no other build or test command)
wall: 1m28s  sequential-equivalent: 1m10s  builds: 7  max-concurrent-builds: 1  rows: 1 green 0 red 0 skipped
outputs: deleted bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/
evidence: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-143342-df6c/report.md
verdict: GREEN exit=0
