--- checkpoint report ---
run: 20261003-145410-8107   manifest: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-145410-8107/manifest.resolved.yaml
commit: faf8cdaa3ea3151a6a7747960feb39db0ed1704e  branch: feat/card-task-b5228641  worktree: /work/worktrees/task-b5228641  host: Debian GNU/Linux 12 (bookworm) cores=24
source: faf8cdaa3ea3151a6a7747960feb39db0ed1704e state=clean buildSource=unknown
CHECKPOINT CP-3 commit=faf8cdaa3ea3151a6a7747960feb39db0ed1704e build=failed filter=/*/*/RunnerCodexCliEvidenceTests*/C959_* executed=n/a passed=n/a failed=n/a skipped=n/a trx=n/a slot=skipped waited=0s dirty=0 source=faf8cdaa3ea3151a6a7747960feb39db0ed1704e sourceState=clean buildSource=unknown
unlisted: none (the tool ran no other build or test command)
wall: 1m24s  sequential-equivalent: 0m00s  builds: 7  max-concurrent-builds: 1  rows: 0 green 1 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-145410-8107
evidence: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-145410-8107/report.md
verdict: RED exit=2
