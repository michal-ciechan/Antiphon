--- checkpoint report ---
run: 20261003-150422-56d4   manifest: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-150422-56d4/manifest.resolved.yaml
commit: 6e67a66dcc1cce1d340f026af84b5ce4cf44b4f7  branch: feat/card-task-b5228641  worktree: /work/worktrees/task-b5228641  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 6e67a66dcc1cce1d340f026af84b5ce4cf44b4f7 state=clean buildSource=verified
CHECKPOINT CP-1 commit=6e67a66dcc1cce1d340f026af84b5ce4cf44b4f7 build=ok filter=/*/*/CodexCliVersionProbeTests*/C959_* executed=5 passed=5 failed=0 skipped=0 trx=/work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-150422-56d4/rows/CP-1/run.trx slot=granted waited=0s dirty=0 source=6e67a66dcc1cce1d340f026af84b5ce4cf44b4f7 sourceState=clean buildSource=verified
PHASES CP-1 slotWait=0s build=16.5500881s startup=2.8790588s testsWall=63.8641402s teardown=0.6073824s hostWall=67.3506089s
SLOW CLASS Antiphon.SessionRunner.Tests.CodexCliVersionProbeTests 63s tests=5 (CP-1)
CHECKPOINT CP-4 commit=6e67a66dcc1cce1d340f026af84b5ce4cf44b4f7 build=ok filter=/*/*/CodexCliAdmissionTests*/C959_* executed=1 passed=0 failed=1 skipped=0 trx=/work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-150422-56d4/rows/CP-4/run.trx slot=granted waited=0s dirty=0 source=6e67a66dcc1cce1d340f026af84b5ce4cf44b4f7 sourceState=clean buildSource=verified
PHASES CP-4 slotWait=0s build=101.7653674s startup=4.771411s testsWall=0.0701683s teardown=0.6917272s hostWall=5.5333064s
FAILED Antiphon.Tests.Application.CodexCliAdmissionTests.C959_Ladder_and_exact_models_share_floor (CP-4) ShouldAssertException: Floor(AgentKind.Codex, model)     should be "0.159.1"     but was null  Additional Info:     C959-v14-floor High -> rows/CP-4/failures.md
unlisted: none (the tool ran no other build or test command)
wall: 3m13s  sequential-equivalent: 1m14s  builds: 7  max-concurrent-builds: 1  rows: 1 green 1 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-150422-56d4
evidence: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-150422-56d4/report.md
verdict: RED exit=1
