--- checkpoint report ---
run: 20261003-142007-63d2   manifest: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-142007-63d2/manifest.resolved.yaml
commit: b2c4a235713c788b9e0b8951f122cdb60a4af6fc  branch: feat/card-task-b5228641  worktree: /work/worktrees/task-b5228641  host: Debian GNU/Linux 12 (bookworm) cores=24
source: b2c4a235713c788b9e0b8951f122cdb60a4af6fc state=clean buildSource=verified
CHECKPOINT CP-1 commit=b2c4a235713c788b9e0b8951f122cdb60a4af6fc build=ok filter=/*/*/CodexCliVersionProbeTests*/C959_* executed=5 passed=5 failed=0 skipped=0 trx=/work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-142007-63d2/rows/CP-1/run.trx slot=granted waited=0s dirty=0 source=b2c4a235713c788b9e0b8951f122cdb60a4af6fc sourceState=clean buildSource=verified
PHASES CP-1 slotWait=0s build=19.0808137s startup=2.2843187s testsWall=22.2871551s teardown=0.5637585s hostWall=25.1352498s
unlisted: none (the tool ran no other build or test command)
wall: 0m45s  sequential-equivalent: 0m25s  builds: 7  max-concurrent-builds: 1  rows: 1 green 0 red 0 skipped
outputs: deleted bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/
evidence: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-142007-63d2/report.md
verdict: GREEN exit=0
