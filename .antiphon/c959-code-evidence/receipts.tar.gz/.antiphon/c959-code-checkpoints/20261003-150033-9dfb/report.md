--- checkpoint report ---
run: 20261003-150033-9dfb   manifest: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-150033-9dfb/manifest.resolved.yaml
commit: ed67126e9e6db23168efdfad7a106e646c80d564  branch: feat/card-task-b5228641  worktree: /work/worktrees/task-b5228641  host: Debian GNU/Linux 12 (bookworm) cores=24
source: ed67126e9e6db23168efdfad7a106e646c80d564 state=clean buildSource=unknown
CHECKPOINT CP-1 commit=ed67126e9e6db23168efdfad7a106e646c80d564 build=failed filter=/*/*/CodexCliVersionProbeTests*/C959_* executed=n/a passed=n/a failed=n/a skipped=n/a trx=n/a slot=skipped waited=0s dirty=0 source=ed67126e9e6db23168efdfad7a106e646c80d564 sourceState=clean buildSource=unknown
CHECKPOINT CP-3 commit=ed67126e9e6db23168efdfad7a106e646c80d564 build=ok filter=/*/*/RunnerCodexCliEvidenceTests*/C959_* executed=5 passed=5 failed=0 skipped=0 trx=/work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-150033-9dfb/rows/CP-3/run.trx slot=granted waited=0s dirty=0 source=ed67126e9e6db23168efdfad7a106e646c80d564 sourceState=clean buildSource=verified
PHASES CP-3 slotWait=0s build=93.2498787s startup=4.4247632s testsWall=4.81524s teardown=0.4548238s hostWall=9.6950098s
unlisted: none (the tool ran no other build or test command)
wall: 1m58s  sequential-equivalent: 0m10s  builds: 7  max-concurrent-builds: 1  rows: 1 green 1 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-150033-9dfb
evidence: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-150033-9dfb/report.md
verdict: RED exit=2
