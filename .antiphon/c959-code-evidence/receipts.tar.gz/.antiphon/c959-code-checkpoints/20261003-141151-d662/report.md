--- checkpoint report ---
run: 20261003-141151-d662   manifest: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-141151-d662/manifest.resolved.yaml
commit: bd5f25244b0cfcc2acc0ce7ecca49456ebec1bec  branch: feat/card-task-b5228641  worktree: /work/worktrees/task-b5228641  host: Debian GNU/Linux 12 (bookworm) cores=24
source: bd5f25244b0cfcc2acc0ce7ecca49456ebec1bec state=clean buildSource=verified
CHECKPOINT CP-1 commit=bd5f25244b0cfcc2acc0ce7ecca49456ebec1bec build=ok filter=/*/*/CodexCliVersionProbeTests*/C959_* executed=5 passed=1 failed=4 skipped=0 trx=/work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-141151-d662/rows/CP-1/run.trx slot=granted waited=0s dirty=0 source=bd5f25244b0cfcc2acc0ce7ecca49456ebec1bec sourceState=clean buildSource=verified
PHASES CP-1 slotWait=0s build=17.4550424s startup=3.0391065s testsWall=8.7948458s teardown=0.490342s hostWall=12.3243168s
FAILED Antiphon.SessionRunner.Tests.CodexCliVersionProbeTests.C959_Probe_is_version_only_and_auth_free (CP-1) InvalidOperationException: No process is associated with this object. -> rows/CP-1/failures.md
FAILED Antiphon.SessionRunner.Tests.CodexCliVersionProbeTests.C959_Failure_bounds_and_cleanup (CP-1) InvalidOperationException: No process is associated with this object. -> rows/CP-1/failures.md
FAILED Antiphon.SessionRunner.Tests.CodexCliVersionProbeTests.C959_Refresh_replaces_evidence (CP-1) InvalidOperationException: No process is associated with this object. -> rows/CP-1/failures.md
FAILED Antiphon.SessionRunner.Tests.CodexCliVersionProbeTests.C959_Local_and_registration_share_snapshot (CP-1) InvalidOperationException: No process is associated with this object. -> rows/CP-1/failures.md
unlisted: none (the tool ran no other build or test command)
wall: 0m31s  sequential-equivalent: 0m13s  builds: 7  max-concurrent-builds: 1  rows: 0 green 1 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-141151-d662
evidence: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-141151-d662/report.md
verdict: RED exit=1
