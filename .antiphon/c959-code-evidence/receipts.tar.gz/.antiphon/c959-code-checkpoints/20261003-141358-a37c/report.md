--- checkpoint report ---
run: 20261003-141358-a37c   manifest: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-141358-a37c/manifest.resolved.yaml
commit: 38f3691e21aeecc2236629f7d09a41a4906d4895  branch: feat/card-task-b5228641  worktree: /work/worktrees/task-b5228641  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 38f3691e21aeecc2236629f7d09a41a4906d4895 state=clean buildSource=verified
CHECKPOINT CP-1 commit=38f3691e21aeecc2236629f7d09a41a4906d4895 build=ok filter=/*/*/CodexCliVersionProbeTests*/C959_* executed=5 passed=5 failed=0 skipped=0 trx=/work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-141358-a37c/rows/CP-1/run.trx slot=granted waited=0s dirty=0 source=38f3691e21aeecc2236629f7d09a41a4906d4895 sourceState=clean buildSource=verified
PHASES CP-1 slotWait=0s build=18.6301674s startup=2.8374496s testsWall=12.7266179s teardown=0.6151172s hostWall=16.1792049s
unlisted: none (the tool ran no other build or test command)
wall: 0m36s  sequential-equivalent: 0m16s  builds: 7  max-concurrent-builds: 1  rows: 1 green 0 red 0 skipped
outputs: deleted bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/
evidence: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-141358-a37c/report.md
verdict: GREEN exit=0
