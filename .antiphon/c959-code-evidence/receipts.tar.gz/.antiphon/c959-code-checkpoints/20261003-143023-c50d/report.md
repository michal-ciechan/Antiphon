--- checkpoint report ---
run: 20261003-143023-c50d   manifest: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-143023-c50d/manifest.resolved.yaml
commit: 1af52f767b1fbff0793ea5b1dc5cc4f8548f4e98  branch: feat/card-task-b5228641  worktree: /work/worktrees/task-b5228641  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 1af52f767b1fbff0793ea5b1dc5cc4f8548f4e98 state=clean buildSource=verified
CHECKPOINT CP-1 commit=1af52f767b1fbff0793ea5b1dc5cc4f8548f4e98 build=ok filter=/*/*/CodexCliVersionProbeTests*/C959_* executed=5 passed=4 failed=1 skipped=0 trx=/work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-143023-c50d/rows/CP-1/run.trx slot=granted waited=0s dirty=0 source=1af52f767b1fbff0793ea5b1dc5cc4f8548f4e98 sourceState=clean buildSource=verified
PHASES CP-1 slotWait=0s build=17.6672705s startup=3.0934667s testsWall=64.3314645s teardown=0.5788255s hostWall=68.0037363s
FAILED Antiphon.SessionRunner.Tests.CodexCliVersionProbeTests.C959_Refresh_replaces_evidence (CP-1) ShouldAssertException: periodic.Starts.Count     should be 2     but was 1  Additional Info:     C959-pc-042 -> rows/CP-1/failures.md
SLOW CLASS Antiphon.SessionRunner.Tests.CodexCliVersionProbeTests 64s tests=5 (CP-1)
unlisted: none (the tool ran no other build or test command)
wall: 1m27s  sequential-equivalent: 1m08s  builds: 7  max-concurrent-builds: 1  rows: 0 green 1 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-143023-c50d
evidence: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-143023-c50d/report.md
verdict: RED exit=1
