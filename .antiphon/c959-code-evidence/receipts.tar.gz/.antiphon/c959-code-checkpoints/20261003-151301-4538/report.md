--- checkpoint report ---
run: 20261003-151301-4538   manifest: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-151301-4538/manifest.resolved.yaml
commit: daa8bd24a417e8df2d31c05dc52cf278c65aac7b  branch: feat/card-task-b5228641  worktree: /work/worktrees/task-b5228641  host: Debian GNU/Linux 12 (bookworm) cores=24
source: daa8bd24a417e8df2d31c05dc52cf278c65aac7b state=clean buildSource=verified
CHECKPOINT CP-1 commit=daa8bd24a417e8df2d31c05dc52cf278c65aac7b build=ok filter=/*/*/CodexCliVersionProbeTests*/C959_* executed=5 passed=5 failed=0 skipped=0 trx=/work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-151301-4538/rows/CP-1/run.trx slot=granted waited=0s dirty=0 source=daa8bd24a417e8df2d31c05dc52cf278c65aac7b sourceState=clean buildSource=verified
PHASES CP-1 slotWait=0s build=17.6547483s startup=2.7874177s testsWall=64.3172885s teardown=0.5458388s hostWall=67.650555s
SLOW CLASS Antiphon.SessionRunner.Tests.CodexCliVersionProbeTests 64s tests=5 (CP-1)
CHECKPOINT CP-3 commit=daa8bd24a417e8df2d31c05dc52cf278c65aac7b build=ok filter=/*/*/RunnerCodexCliEvidenceTests*/C959_* executed=5 passed=5 failed=0 skipped=0 trx=/work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-151301-4538/rows/CP-3/run.trx slot=granted waited=0s dirty=0 source=daa8bd24a417e8df2d31c05dc52cf278c65aac7b sourceState=clean buildSource=verified
PHASES CP-3 slotWait=0s build=103.5622809s startup=3.8505969s testsWall=5.0427453s teardown=0.565394s hostWall=9.4587368s
CHECKPOINT CP-4 commit=daa8bd24a417e8df2d31c05dc52cf278c65aac7b build=ok filter=/*/*/CodexCliAdmissionTests*/C959_* executed=1 passed=1 failed=0 skipped=0 trx=/work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-151301-4538/rows/CP-4/run.trx slot=granted waited=0s dirty=0 source=daa8bd24a417e8df2d31c05dc52cf278c65aac7b sourceState=clean buildSource=verified
PHASES CP-4 slotWait=0s build=90.4447206s startup=4.1634576s testsWall=0.0279655s teardown=0.7475957s hostWall=4.9390189s
CHECKPOINT CP-5 commit=daa8bd24a417e8df2d31c05dc52cf278c65aac7b build=ok filter=/*/*/(CodexPhoneHomeCreateTests*)|(PinnedCodexProfileDispatchLaunchTests*)|(ModelAvailabilityCreateTests*)|(ModelAvailabilityDispatcherTests*)/* executed=22 passed=22 failed=0 skipped=0 trx=/work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-151301-4538/rows/CP-5/run.trx slot=granted waited=0s dirty=0 source=daa8bd24a417e8df2d31c05dc52cf278c65aac7b sourceState=clean buildSource=verified
PHASES CP-5 slotWait=0s build=91.3041s startup=40.1702653s testsWall=22.4605521s teardown=1.2732029s hostWall=63.9040208s
CHECKPOINT CP-6 commit=daa8bd24a417e8df2d31c05dc52cf278c65aac7b build=ok filter=/*/*/(RunnerCatalogueTests*)|(PhoneHomeDirectoryTests*)|(PhoneHomeRunnerRetirementIdentityTests*)/* executed=20 passed=20 failed=0 skipped=0 trx=/work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-151301-4538/rows/CP-6/run.trx slot=granted waited=0s dirty=0 source=daa8bd24a417e8df2d31c05dc52cf278c65aac7b sourceState=clean buildSource=verified
PHASES CP-6 slotWait=0s build=99.1171806s startup=40.8168059s testsWall=6.9087474s teardown=1.0608082s hostWall=48.7863613s
CHECKPOINT CP-7 commit=daa8bd24a417e8df2d31c05dc52cf278c65aac7b build=ok filter=/*/*/ModelAliasTests*/* executed=76 passed=76 failed=0 skipped=0 trx=/work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-151301-4538/rows/CP-7/run.trx slot=granted waited=0s dirty=0 source=daa8bd24a417e8df2d31c05dc52cf278c65aac7b sourceState=clean buildSource=verified
PHASES CP-7 slotWait=0s build=92.7145763s startup=4.765453s testsWall=0.1473875s teardown=0.7768342s hostWall=5.6896751s
unlisted: none (the tool ran no other build or test command)
wall: 11m40s  sequential-equivalent: 3m23s  builds: 7  max-concurrent-builds: 1  rows: 5 green 1 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-151301-4538
evidence: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-151301-4538/report.md
verdict: RED exit=3
