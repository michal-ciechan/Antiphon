--- checkpoint report ---
run: 20261003-143839-b468   manifest: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-143839-b468/manifest.resolved.yaml
commit: 17d5acd8177c357aa45f8d15e7e0e8d5b063d361  branch: feat/card-task-b5228641  worktree: /work/worktrees/task-b5228641  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 17d5acd8177c357aa45f8d15e7e0e8d5b063d361 state=clean buildSource=verified
CHECKPOINT CP-3 commit=17d5acd8177c357aa45f8d15e7e0e8d5b063d361 build=ok filter=/*/*/RunnerCodexCliEvidenceTests*/C959_* executed=5 passed=0 failed=5 skipped=0 trx=/work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-143839-b468/rows/CP-3/run.trx slot=granted waited=0s dirty=0 source=17d5acd8177c357aa45f8d15e7e0e8d5b063d361 sourceState=clean buildSource=verified
PHASES CP-3 slotWait=0s build=105.6864641s startup=4.2418688s testsWall=2.1782033s teardown=0.5797672s hostWall=6.9998559s
FAILED Antiphon.Tests.Application.RunnerCodexCliEvidenceTests.C959_Heartbeat_updates_only_probe_evidence (CP-3) ShouldAssertException: Text(status, "codexCliVersion")     should be "0.160.0"     but was null  Additional Info:     C959-v09-newer -> rows/CP-3/failures.md
FAILED Antiphon.Tests.Application.RunnerCodexCliEvidenceTests.C959_Freshness_boundaries (CP-3) ServiceUnavailableException: Phone-home runner has not completed recovery. -> rows/CP-3/failures.md
FAILED Antiphon.Tests.Application.RunnerCodexCliEvidenceTests.C959_Generation_change_clears_version (CP-3) ShouldAssertException: descriptor!.Capabilities!.CodexCliVersion     should be null but was "0.160.0"  Additional Info:     C959-v11-register-clear -> rows/CP-3/failures.md
FAILED Antiphon.Tests.Application.RunnerCodexCliEvidenceTests.C959_Catalogue_and_status_project_version (CP-3) ShouldAssertException: Text(desktop, "codexCliVersion")     should be "0.159.1"     but was null  Additional Info:     C959-v12-desktop -> rows/CP-3/failures.md
FAILED Antiphon.Tests.Application.RunnerCodexCliEvidenceTests.C959_Exact_probe_transport_is_bound (CP-3) ShouldAssertException: sample?.CodexCliVersion     should be "0.159.1"     but was null  Additional Info:     C959-v13-phone-home -> rows/CP-3/failures.md
unlisted: none (the tool ran no other build or test command)
wall: 1m54s  sequential-equivalent: 0m07s  builds: 7  max-concurrent-builds: 1  rows: 0 green 1 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-143839-b468
evidence: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-143839-b468/report.md
verdict: RED exit=1
