--- checkpoint report ---
run: 20261003-140354-dd46   manifest: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-140354-dd46/manifest.resolved.yaml
commit: 49b556595abc8dee3e17cc95e5b199fab6191e3d  branch: feat/card-task-b5228641  worktree: /work/worktrees/task-b5228641  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 49b556595abc8dee3e17cc95e5b199fab6191e3d state=clean buildSource=verified
CHECKPOINT CP-1 commit=49b556595abc8dee3e17cc95e5b199fab6191e3d build=ok filter=/*/*/CodexCliVersionProbeTests*/C959_* executed=5 passed=1 failed=4 skipped=0 trx=/work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-140354-dd46/rows/CP-1/run.trx slot=granted waited=0s dirty=0 source=49b556595abc8dee3e17cc95e5b199fab6191e3d sourceState=clean buildSource=verified
PHASES CP-1 slotWait=0s build=23.9474095s startup=3.4911911s testsWall=0.6206135s teardown=0.581993s hostWall=4.6938158s
FAILED Antiphon.SessionRunner.Tests.CodexCliVersionProbeTests.C959_Probe_is_version_only_and_auth_free (CP-1) ShouldAssertException: CodexCliVersionTestFixture.Text(sample, "codexCliVersion")     should be "0.160.0"     but was null  Additional Info:     C959-v02-argv -> rows/CP-1/failures.md
FAILED Antiphon.SessionRunner.Tests.CodexCliVersionProbeTests.C959_Failure_bounds_and_cleanup (CP-1) ShouldAssertException: CodexCliVersionTestFixture.Text(sample, "codexCliVersionError")     should be "nonzero_exit"     but was null  Additional Info:     C959-pc-028 -> rows/CP-1/failures.md
FAILED Antiphon.SessionRunner.Tests.CodexCliVersionProbeTests.C959_Refresh_replaces_evidence (CP-1) ShouldAssertException: CodexCliVersionTestFixture.Text(kit.Local(), "codexCliVersion")     should be "0.160.0"     but was null  Additional Info:     C959-v04-replaced -> rows/CP-1/failures.md
FAILED Antiphon.SessionRunner.Tests.CodexCliVersionProbeTests.C959_Local_and_registration_share_snapshot (CP-1) ShouldAssertException: local.TryGetProperty("codexCliVersion", out _)     should be True     but was False  Additional Info:     C959-v05-local -> rows/CP-1/failures.md
unlisted: none (the tool ran no other build or test command)
wall: 0m30s  sequential-equivalent: 0m05s  builds: 7  max-concurrent-builds: 1  rows: 0 green 1 red 0 skipped
outputs: kept bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-140354-dd46
evidence: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-140354-dd46/report.md
verdict: RED exit=1
