--- checkpoint report ---
run: 20261003-144625-1a76   manifest: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-144625-1a76/manifest.resolved.yaml
commit: 7d453cd7ee2499a1fe48ce508201ffbf5ce293d2  branch: feat/card-task-b5228641  worktree: /work/worktrees/task-b5228641  host: Debian GNU/Linux 12 (bookworm) cores=24
source: 7d453cd7ee2499a1fe48ce508201ffbf5ce293d2 state=clean buildSource=verified
CHECKPOINT CP-3 commit=7d453cd7ee2499a1fe48ce508201ffbf5ce293d2 build=ok filter=/*/*/RunnerCodexCliEvidenceTests*/C959_* executed=5 passed=5 failed=0 skipped=0 trx=/work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-144625-1a76/rows/CP-3/run.trx slot=granted waited=0s dirty=0 source=7d453cd7ee2499a1fe48ce508201ffbf5ce293d2 sourceState=clean buildSource=verified
PHASES CP-3 slotWait=0s build=88.442898s startup=4.6597917s testsWall=2.2446038s teardown=0.5947556s hostWall=7.4994406s
CHECKPOINT CP-6 commit=7d453cd7ee2499a1fe48ce508201ffbf5ce293d2 build=ok filter=/*/*/(RunnerCatalogueTests*)|(PhoneHomeDirectoryTests*)|(PhoneHomeRunnerRetirementIdentityTests*)/* executed=20 passed=20 failed=0 skipped=0 trx=/work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-144625-1a76/rows/CP-6/run.trx slot=granted waited=0s dirty=0 source=7d453cd7ee2499a1fe48ce508201ffbf5ce293d2 sourceState=clean buildSource=verified
PHASES CP-6 slotWait=0s build=85.4531038s startup=39.8422856s testsWall=5.9283903s teardown=1.3450051s hostWall=47.1156814s
unlisted: none (the tool ran no other build or test command)
wall: 3m50s  sequential-equivalent: 0m55s  builds: 7  max-concurrent-builds: 1  rows: 2 green 0 red 0 skipped
outputs: deleted bin-c959-probe/, bin-c959-windows/, bin-c959-evidence/, bin-c959-admission/, bin-c959-auth/, bin-c959-directory/, bin-c959-models/
evidence: /work/worktrees/task-b5228641/.antiphon/c959-code-checkpoints/20261003-144625-1a76/report.md
verdict: GREEN exit=0
