--- checkpoint report ---
run: 20261003-102539-1ae3   manifest: /work/worktrees/task-e1b6cb4a/.antiphon/checkpoints/20261003-102539-1ae3/manifest.resolved.yaml
commit: c4a723b830fa6e12934c3d962aaeeae7128d802a  branch: feat/card-task-e1b6cb4a  worktree: /work/worktrees/task-e1b6cb4a  host: Debian GNU/Linux 12 (bookworm) cores=24
source: c4a723b830fa6e12934c3d962aaeeae7128d802a state=clean buildSource=verified
CHECKPOINT CP-0 commit=c4a723b830fa6e12934c3d962aaeeae7128d802a build=ok filter=/*/*/ProviderOracleGateTests*/Disabled_gate_skips_before_the_oracle_body executed=6 passed=0 failed=6 skipped=0 trx=/work/worktrees/task-e1b6cb4a/.antiphon/checkpoints/20261003-102539-1ae3/rows/CP-0/run.trx slot=granted waited=0s dirty=0 source=c4a723b830fa6e12934c3d962aaeeae7128d802a sourceState=clean buildSource=verified
PHASES CP-0 slotWait=0s build=26.9545161s startup=4.2977215s testsWall=0.1327319s teardown=0.8948031s hostWall=5.3252643s
FAILED Antiphon.Agents.Pty.Tests.ProviderOracleGateTests.Disabled_gate_skips_before_the_oracle_body (CP-0) ShouldAssertException: type     should not be null but was  Additional Info:     ordinary provider oracle selection requires an opt-in gate -> rows/CP-0/failures.md
FAILED Antiphon.Agents.Pty.Tests.ProviderOracleGateTests.Disabled_gate_skips_before_the_oracle_body (CP-0) ShouldAssertException: type     should not be null but was  Additional Info:     ordinary provider oracle selection requires an opt-in gate -> rows/CP-0/failures.md
FAILED Antiphon.Agents.Pty.Tests.ProviderOracleGateTests.Disabled_gate_skips_before_the_oracle_body (CP-0) ShouldAssertException: type     should not be null but was  Additional Info:     ordinary provider oracle selection requires an opt-in gate -> rows/CP-0/failures.md
FAILED Antiphon.Agents.Pty.Tests.ProviderOracleGateTests.Disabled_gate_skips_before_the_oracle_body (CP-0) ShouldAssertException: type     should not be null but was  Additional Info:     ordinary provider oracle selection requires an opt-in gate -> rows/CP-0/failures.md
FAILED Antiphon.Agents.Pty.Tests.ProviderOracleGateTests.Disabled_gate_skips_before_the_oracle_body (CP-0) ShouldAssertException: type     should not be null but was  Additional Info:     ordinary provider oracle selection requires an opt-in gate -> rows/CP-0/failures.md
FAILED Antiphon.Agents.Pty.Tests.ProviderOracleGateTests.Disabled_gate_skips_before_the_oracle_body (CP-0) ShouldAssertException: type     should not be null but was  Additional Info:     ordinary provider oracle selection requires an opt-in gate -> rows/CP-0/failures.md
unlisted: none (the tool ran no other build or test command)
wall: 0m34s  sequential-equivalent: 0m06s  builds: 3  max-concurrent-builds: 1  rows: 0 green 1 red 0 skipped
outputs: kept bin-c1007-red/, bin-c1007-pty/, bin-c1007-unit/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-102539-1ae3
evidence: /work/worktrees/task-e1b6cb4a/.antiphon/checkpoints/20261003-102539-1ae3/report.md
verdict: RED exit=1
