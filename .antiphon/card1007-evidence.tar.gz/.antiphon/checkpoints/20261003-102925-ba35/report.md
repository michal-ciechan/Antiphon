--- checkpoint report ---
run: 20261003-102925-ba35   manifest: /work/worktrees/task-e1b6cb4a/.antiphon/checkpoints/20261003-102925-ba35/manifest.resolved.yaml
commit: f3af343ffef896fe2381c05f968a108e6d599a96  branch: feat/card-task-e1b6cb4a  worktree: /work/worktrees/task-e1b6cb4a  host: Debian GNU/Linux 12 (bookworm) cores=24
source: f3af343ffef896fe2381c05f968a108e6d599a96 state=clean buildSource=verified
CHECKPOINT CP-1 commit=f3af343ffef896fe2381c05f968a108e6d599a96 build=ok filter=/*/*/(OrchestratorWorkspaceLayoutCanaryTests*)|(ProviderOracleGateTests*)/* executed=7 passed=7 failed=0 skipped=2 trx=/work/worktrees/task-e1b6cb4a/.antiphon/checkpoints/20261003-102925-ba35/rows/CP-1/run.trx slot=granted waited=0s dirty=0 source=f3af343ffef896fe2381c05f968a108e6d599a96 sourceState=clean buildSource=verified
PHASES CP-1 slotWait=0s build=63.9208141s startup=4.480596s testsWall=0.2165854s teardown=1.0138259s hostWall=5.711036s
CHECKPOINT CP-2 commit=f3af343ffef896fe2381c05f968a108e6d599a96 build=reused filter=/*/*/*/*[Category=Unit] executed=321 passed=321 failed=0 skipped=2 trx=/work/worktrees/task-e1b6cb4a/.antiphon/checkpoints/20261003-102925-ba35/rows/CP-2/run.trx slot=granted waited=0s dirty=0 source=f3af343ffef896fe2381c05f968a108e6d599a96 sourceState=clean buildSource=verified
PHASES CP-2 slotWait=0s build=0s startup=6.2406181s testsWall=8.0713018s teardown=0.7792091s hostWall=15.091129s
SLOW CLASS Antiphon.Agents.Pty.Tests.ClaudeEffortPromptTests 67s tests=64 (CP-2)
CHECKPOINT CP-4 commit=f3af343ffef896fe2381c05f968a108e6d599a96 build=reused filter=/*/*/(CheckpointManifestDocumentationTests*)|(ScopedVerificationInstructionTests*)|(RunnerDefaultGuidanceTests*)|(DockerStackDocumentationTests*)|(GrokRunnerImageContractTests*)|(CheckpointRepeatDocumentationTests*)/* executed=65 passed=65 failed=0 skipped=0 trx=/work/worktrees/task-e1b6cb4a/.antiphon/checkpoints/20261003-102925-ba35/rows/CP-4/run.trx slot=granted waited=0s dirty=0 source=f3af343ffef896fe2381c05f968a108e6d599a96 sourceState=clean buildSource=verified
PHASES CP-4 slotWait=0s build=321.6695464s startup=5.4639299s testsWall=0.5225956s teardown=0.7249251s hostWall=6.7114501s
CHECKPOINT CP-3 commit=f3af343ffef896fe2381c05f968a108e6d599a96 build=ok filter=/*/*/*/*[Category=Unit] executed=3910 passed=3910 failed=0 skipped=52 trx=/work/worktrees/task-e1b6cb4a/.antiphon/checkpoints/20261003-102925-ba35/rows/CP-3/run.trx slot=granted waited=0s dirty=0 source=f3af343ffef896fe2381c05f968a108e6d599a96 sourceState=clean buildSource=verified
PHASES CP-3 slotWait=0s build=0s startup=182.0047407s testsWall=208.0261622s teardown=3.1366341s hostWall=393.1675367s
SLOW CLASS Antiphon.Tests.AgentTui.AgentTuiSecretProtectorTests 111s tests=65 (CP-3)
SLOW CLASS Antiphon.Tests.Checkpoints.PlanCoverageCommandTests 103s tests=10 (CP-3)
SLOW CLASS Antiphon.Tests.TestHelpers.TestClassificationPolicyTests 97s tests=25 (CP-3)
SLOW CLASS Antiphon.Tests.Application.WorktreeCleanupPresentationTests 96s tests=33 (CP-3)
SLOW CLASS Antiphon.Tests.Scripts.RemoteScriptContractTests 90s tests=65 (CP-3)
SLOW CLASS Antiphon.Tests.Checkpoints.PlanCoverageGoldenTests 74s tests=4 (CP-3)
SLOW CLASS Antiphon.Tests.Application.ChannelOutboundStorageTests 71s tests=28 (CP-3)
SLOW CLASS Antiphon.Tests.Checkpoints.CheckpointTaskOwnershipTests 69s tests=23 (CP-3)
SLOW CLASS Antiphon.Tests.Infrastructure.LogRetentionTests 61s tests=21 (CP-3)
CHECKPOINT CP-5 commit=f3af343ffef896fe2381c05f968a108e6d599a96 build=reused filter=/*/*/OrchestratorWorkspaceLayoutCanaryTests*/(Codex_prompt_input_is_bounded_at_the_nested_checkout_git_root*)|(Grok_inspect_is_bounded_at_the_nested_checkout_git_root*) executed=2 passed=1 failed=1 skipped=0 trx=/work/worktrees/task-e1b6cb4a/.antiphon/checkpoints/20261003-102925-ba35/rows/CP-5/run.trx slot=granted waited=0s dirty=0 source=f3af343ffef896fe2381c05f968a108e6d599a96 sourceState=clean buildSource=verified
PHASES CP-5 slotWait=0s build=0s startup=3.0752454s testsWall=0.8096947s teardown=0.3915393s hostWall=4.2764789s
FAILED Antiphon.Agents.Pty.Tests.OrchestratorWorkspaceLayoutCanaryTests.Grok_inspect_is_bounded_at_the_nested_checkout_git_root (CP-5) ShouldAssertException: projectPaths     should not be empty but was  Additional Info:     the checkout's AGENTS.md / CLAUDE.md must appear as project instructions -> rows/CP-5/failures.md
unlisted: none (the tool ran no other build or test command)
wall: 13m28s  sequential-equivalent: 7m08s  builds: 3  max-concurrent-builds: 1  rows: 4 green 1 red 0 skipped
outputs: kept bin-c1007-red/, bin-c1007-pty/, bin-c1007-unit/ -> dotnet run --project tools/Antiphon.Checkpoints -- clean --run 20261003-102925-ba35
evidence: /work/worktrees/task-e1b6cb4a/.antiphon/checkpoints/20261003-102925-ba35/report.md
verdict: RED exit=1
